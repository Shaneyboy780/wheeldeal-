--[[
    AutoTrader LS (resource: wheeldeal)
    Player-to-player vehicle marketplace app for LB-Phone (QBCore + oxmysql)

    This file is SHARED (loaded on client and server). Anything the UI needs is
    forwarded to it through a callback in client.lua, so the client never trusts
    raw config for security-relevant decisions - the server re-validates everything.
]]

Config = {}

------------------------------------------------------------------------
-- APP / IDENTITY
------------------------------------------------------------------------
Config.AppName      = "AutoTrader LS"          -- shown in the phone OS + app store
Config.Identifier   = "wheeldeal"              -- internal LB-Phone app id (keep unique)
Config.Developer    = "Your Server"
Config.Description  = "Buy & sell player vehicles"
Config.DefaultApp   = true                      -- true = pre-installed, false = download from app store
Config.AppSize      = 48211                      -- cosmetic, kB shown in storage

-- App store screenshots (optional). Leave {} or add public URLs.
Config.Images = {}

------------------------------------------------------------------------
-- ECONOMY
------------------------------------------------------------------------
Config.Currency             = "$"
Config.BuyerAccount         = "bank"            -- account money is taken FROM the buyer
Config.SellerAccount        = "bank"            -- account money is paid TO the seller
Config.MinPrice             = 1
Config.MaxPrice             = 100000000         -- 100m hard cap (anti-fat-finger / overflow guard)

-- Optional non-refundable fee charged when a listing is created
Config.ListingFee           = {
    enabled = false,
    amount  = 500,
    account = "bank",
}

------------------------------------------------------------------------
-- LISTINGS
------------------------------------------------------------------------
Config.MaxImagesPerListing  = 8
Config.MaxActiveListings    = 10                -- per player, 0 = unlimited
Config.ListingDurationDays  = 30                -- auto-expire after N days (0 = never expire)
Config.ExpireCheckMinutes   = 30               -- how often the server sweeps for expired listings

Config.MaxTitleLength       = 60
Config.MaxDescriptionLength = 600
Config.MaxContactLength     = 160

-- Cooldowns (seconds) to stop spam / abuse
Config.Cooldowns = {
    createListing = 15,
    submitOffer   = 5,
    sendMessage   = 5,
}

------------------------------------------------------------------------
-- VEHICLE OWNERSHIP / GARAGE
------------------------------------------------------------------------
-- After a successful sale the vehicle row in `player_vehicles` is reassigned to
-- the buyer. These control where it lands for them.
Config.GarageOnSale         = "pillboxgarage"   -- garage the bought vehicle is parked in
Config.StateOnSale          = 1                  -- qb-garages state: 1 = stored in garage
Config.BlockFinancedSales   = true               -- don't allow selling vehicles that still owe finance payments

-- Column names in player_vehicles (change ONLY if your schema is customised)
Config.VehicleTable = {
    name       = "player_vehicles",
    owner      = "citizenid",     -- column that stores the owning citizenid
    license    = "license",       -- column that stores the owning license/identifier
    plate      = "plate",
    model      = "vehicle",       -- column that stores the spawn name (e.g. "sultan")
    garage     = "garage",
    state      = "state",
    financetime= "financetime",   -- used for the financed-sale check (set to false to skip)
}

------------------------------------------------------------------------
-- CATEGORIES
------------------------------------------------------------------------
-- Marketplace filter categories. `key` is stored in the DB, `label` is shown.
Config.AllowEmergencyCategory = false
Config.Categories = {
    { key = "cars",        label = "Cars" },
    { key = "suvs",        label = "SUVs" },
    { key = "trucks",      label = "Trucks" },
    { key = "motorcycles", label = "Motorcycles" },
    { key = "imports",     label = "Imports" },
    { key = "luxury",      label = "Luxury" },
    { key = "sports",      label = "Sports" },
    -- emergency is appended automatically below if enabled
}

-- Maps QBCore shared-vehicle categories -> our marketplace categories so we can
-- pre-select a sensible category when the seller picks a vehicle.
Config.CategoryMap = {
    sports        = "sports",
    super         = "sports",
    sportsclassics= "luxury",
    muscle        = "cars",
    sedans        = "cars",
    compacts      = "cars",
    coupes        = "cars",
    suvs          = "suvs",
    offroad       = "suvs",
    vans          = "trucks",
    industrial    = "trucks",
    utility       = "trucks",
    commercial    = "trucks",
    motorcycles   = "motorcycles",
    cycles        = "motorcycles",
    emergency     = "emergency",
    military      = "imports",
    imports       = "imports",
}

------------------------------------------------------------------------
-- IMAGE SECURITY
------------------------------------------------------------------------
-- LB-Phone's gallery returns already-uploaded URLs from your upload host.
-- Leave AllowedImageDomains empty to accept any https URL, or lock it to your
-- upload host(s) to stop image injection (recommended).
-- Example: { "fivemanage.com", "your-bucket.r2.dev" }
Config.AllowedImageDomains  = {}
Config.MaxImageUrlLength    = 512

------------------------------------------------------------------------
-- ADMIN
------------------------------------------------------------------------
Config.Admin = {
    -- A player passes the admin check if EITHER of these is true.
    useAce      = true,
    acePermission = "wheeldeal.admin",   -- add to server.cfg: add_ace group.admin wheeldeal.admin allow
    useQBPermission = true,
    qbPermission = "admin",              -- QBCore permission level

    commands = {
        removeListing = "wd_remove",     -- /wd_remove [listingId]
        listAll       = "wd_listings",   -- /wd_listings
        salesHistory  = "wd_sales",      -- /wd_sales
        banSeller     = "wd_ban",        -- /wd_ban [citizenid] [reason]
        unbanSeller   = "wd_unban",      -- /wd_unban [citizenid]
    },
}

------------------------------------------------------------------------
-- NOTIFICATIONS
------------------------------------------------------------------------
-- Phone (LB-Phone) notifications are always used for in-app events.
-- These toggles let you mute specific ones.
Config.Notify = {
    newOffer        = true,
    listingSold     = true,
    offerAccepted   = true,
    offerDeclined   = true,
    offerCountered  = true,
    listingExpiring = true,   -- fired ~24h before expiry
}

-- Append emergency category if allowed
if Config.AllowEmergencyCategory then
    Config.Categories[#Config.Categories + 1] = { key = "emergency", label = "Emergency" }
end
