/* AutoTrader LS - dev.js
   IGNORED IN-GAME. When you open ui/index.html in a normal browser this builds
   a phone frame, stubs the LB-Phone helper functions with mock data, and fires
   a synthetic 'componentsLoaded' so app.js runs. In FiveM (window.invokeNative
   present) it just unwraps the app and lets LB-Phone take over. */
window.addEventListener('load', () => {
    const phoneWrapper = document.getElementById('phone-wrapper');
    const app = phoneWrapper.querySelector('.app');

    // ----- In-game: hand control to LB-Phone -----
    // IMPORTANT: do NOT make the body visible here. This same file also runs in
    // the resource's own (always-on) NUI layer, which never receives
    // 'componentsLoaded'. If we revealed it, that empty layer would paint the
    // opaque app background over the whole game = black screen. We leave it
    // hidden; index.html reveals the body only when LB-Phone sends
    // 'componentsLoaded' (which only its app iframe receives).
    if (window.invokeNative) {
        phoneWrapper.parentNode.insertBefore(app, phoneWrapper);
        phoneWrapper.parentNode.removeChild(phoneWrapper);
        return;
    }

    // ----- Browser preview only below -----
    document.body.style.visibility = 'visible';
    const IMGS = [
        'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=700',
        'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=700',
        'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=700',
    ];
    const CATS = [
        { key: 'cars', label: 'Cars' }, { key: 'suvs', label: 'SUVs' }, { key: 'trucks', label: 'Trucks' },
        { key: 'motorcycles', label: 'Motorcycles' }, { key: 'imports', label: 'Imports' },
        { key: 'luxury', label: 'Luxury' }, { key: 'sports', label: 'Sports' },
    ];
    const CARDS = [
        { id: 1, title: 'Clean Sultan RS · Low Miles', model: 'sultanrs', category: 'sports', price: 145000, mileage: 12500, seller_name: 'Mike Toreno', status: 'active', cover: IMGS[0] },
        { id: 2, title: 'Sandking XL Lifted', model: 'sandking', category: 'trucks', price: 89000, mileage: 45200, seller_name: 'Trevor P.', status: 'active', cover: IMGS[1] },
        { id: 3, title: 'Pristine Comet S2', model: 'comet5', category: 'sports', price: 210000, mileage: 3200, seller_name: 'Lester C.', status: 'active', cover: IMGS[2] },
        { id: 4, title: 'Daily Driver Sedan', model: 'asea', category: 'cars', price: 12500, mileage: 98000, seller_name: 'Mike Toreno', status: 'active', cover: null },
    ];
    const FULL = {
        id: 1, title: 'Clean Sultan RS · Low Miles', model: 'sultanrs', modelLabel: 'Sultan RS', brand: 'Karin',
        category: 'sports', plate: 'ATR 1337', price: 145000, mileage: 12500, condition: 4,
        description: 'Garage kept, fully serviced. New tyres, upgraded brakes. No accidents. Serious buyers only.',
        contact: 'Text me anytime, usually free evenings.', sellerName: 'Mike Toreno', sellerNumber: '5550101',
        createdAt: '2026-06-18 12:00:00', status: 'active', images: IMGS, isFavorite: false, isOwner: false, myOffer: null,
    };
    const VEHS = [
        { plate: 'ATR 1337', model: 'sultanrs', label: 'Sultan RS', brand: 'Karin', suggestedCat: 'sports', financed: false, alreadyListed: false },
        { plate: 'XYZ 9988', model: 'kuruma', label: 'Kuruma', brand: 'Karin', suggestedCat: 'sports', financed: true, alreadyListed: false },
        { plate: 'OLD 0001', model: 'asea', label: 'Asea', brand: 'Declasse', suggestedCat: 'cars', financed: false, alreadyListed: true },
    ];
    const DASH = {
        active: [{ id: 1, title: 'Clean Sultan RS', model: 'sultanrs', price: 145000, mileage: 12500, condition: 4, offerCount: 2, cover: IMGS[0] }],
        offers: [
            { id: 11, listing_id: 1, buyer_name: 'Frank T.', amount: 130000, counter_amount: null, status: 'pending', title: 'Clean Sultan RS' },
            { id: 12, listing_id: 1, buyer_name: 'Lamar D.', amount: 120000, counter_amount: 138000, status: 'countered', title: 'Clean Sultan RS' },
        ],
        sold: [{ id: 9, title: 'Old Banshee', model: 'banshee', price: 96000, sold_at: '2026-06-10 09:00:00', via: 'offer' }],
        expired: [{ id: 8, title: 'Project Tampa', model: 'tampa', price: 40000, created_at: '2026-05-01 09:00:00', expires_at: '2026-05-31 09:00:00' }],
    };

    let favOn = false;
    const ok = { success: true };
    function mock(event) {
        switch (event) {
            case 'getMeta': return { citizenid: 'DEV0001', name: 'Dev Player', number: '5550000', isAdmin: true, banned: false, currency: '$', categories: CATS, maxImages: 8, minPrice: 1, maxPrice: 100000000 };
            case 'getMyVehicles': return VEHS;
            case 'getListings': return { listings: CARDS, page: 1, hasMore: false };
            case 'getListing': return Object.assign({}, FULL, { isFavorite: favOn });
            case 'getFavorites': return [CARDS[0], CARDS[2]];
            case 'getDashboard': return DASH;
            case 'toggleFavorite': favOn = !favOn; return { success: true, favorited: favOn };
            case 'messageSeller': return { success: true, message: 'Message sent (dev)' };
            default: return ok; // create/edit/remove/purchase/offer/etc.
        }
    }

    window.fetchNui = (event) => Promise.resolve(mock(event));
    window.selectGallery = (opts) => { const cb = opts.cb || opts.onSelect; cb && cb([{ src: IMGS[Math.floor(Math.random() * IMGS.length)] }]); };
    window.getSettings = () => Promise.resolve({ display: { theme: 'dark' } });
    window.onSettingsChange = () => {};
    window.sendNotification = () => {};
    window.createCall = () => {};

    // build the phone frame
    const frame = document.createElement('div');
    frame.className = 'phone-frame';
    const notch = document.createElement('div'); notch.className = 'phone-notch';
    const content = document.createElement('div'); content.className = 'phone-content';
    content.appendChild(app);
    frame.appendChild(notch); frame.appendChild(content);

    const dev = document.createElement('div'); dev.className = 'dev-wrapper'; dev.style.display = 'block';
    dev.appendChild(frame);
    phoneWrapper.parentNode.insertBefore(dev, phoneWrapper);
    phoneWrapper.parentNode.removeChild(phoneWrapper);

    // kick off the app
    window.dispatchEvent(new MessageEvent('message', { data: 'componentsLoaded' }));
});
