fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'wheeldeal'
author 'Your Server'
description 'AutoTrader LS - player-to-player vehicle marketplace app for LB-Phone (QBCore)'
version '1.0.0'

shared_script 'config.lua'

client_script 'client/client.lua'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/sv_utils.lua',
    'server/sv_main.lua',
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/colors.css',
    'ui/styles.css',
    'ui/app.js',
    'ui/dev.js',
    'ui/assets/*.svg',
}

dependencies {
    'qb-core',
    'oxmysql',
    'lb-phone',
}
