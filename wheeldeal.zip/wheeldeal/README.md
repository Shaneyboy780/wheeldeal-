# AutoTrader LS — vehicle marketplace for LB-Phone

A player-to-player vehicle marketplace app for **LB-Phone** on **QBCore** (with **oxmysql**).
Players list vehicles they personally own, browse and search a marketplace, make offers,
and buy vehicles — all from their phone. Listing a vehicle does **not** remove it from the
seller's garage; ownership only transfers on a completed sale.

- **In-phone app name:** AutoTrader LS
- **Resource folder:** `wheeldeal`
- **Database prefix:** `wheeldeal_`

> Naming note: the brief referred to the project as both "AutoTrader LS" and "WheelDeal".
> This resource uses **AutoTrader LS** as the display name and `wheeldeal` as the folder/DB
> prefix. To rename the app shown on the phone, change `Config.AppName`.

---

## Features

- **Create listings** from owned vehicles only (ownership validated server-side). Title,
  price, mileage, condition rating, description, contact notes, category, and multiple
  photos from the LB-Phone gallery (first photo is the cover).
- **Marketplace** with search by vehicle name or seller, sort (price/date/mileage, asc &
  desc), and category filters (Cars, SUVs, Trucks, Motorcycles, Imports, Luxury, Sports,
  optional Emergency).
- **Vehicle detail** page with a photo carousel, full specs, seller info, and
  Buy Now / Make Offer / Message / Call / Save / Report actions.
- **Favorites** — save and remove listings.
- **Seller dashboard ("Garage")** — Active, Offers, Sold, and Expired tabs; edit, change
  price, add photos, remove, and relist.
- **Purchase system** — atomic, exploit-safe transfer: validates listing, ownership, funds;
  claims the listing; transfers the vehicle pinned to the current owner; moves money; writes
  a sale record; notifies both parties. Rolls back on any failure.
- **Offers** — submit/update an offer; seller can accept, decline, or counter; buyer can
  accept a counter (which completes the purchase).
- **LB-Phone notifications** for new offers, sold, accepted, declined, countered, and
  listings expiring within 24h.
- **Expiration** — configurable (default 30 days); expired listings move to the Expired tab
  and can be relisted.
- **Admin commands** — remove a listing, list recent listings, view sales history, ban/unban
  a seller from the marketplace.

---

## Requirements

- [qb-core](https://github.com/qbcore-framework/qb-core)
- [oxmysql](https://github.com/overextended/oxmysql)
- [lb-phone](https://lbphone.com) (with a configured **photo upload method** — see below)

---

## Installation

1. **Add the resource.** Drop the `wheeldeal` folder into your `resources` directory.

2. **Import the database.** Run `install.sql` against your server database (HeidiSQL,
   phpMyAdmin, or `mysql < install.sql`). It creates all six `wheeldeal_*` tables plus a
   marketplace ban table, with indexes. It is safe to re-run.

3. **Configure LB-Phone photo uploads.** The gallery photo picker stores image **URLs** from
   LB-Phone's upload host. In `lb-phone` set an upload method (Fivemanage or lb-presigned)
   and enter your keys in `lb-phone/server/apiKeys.lua`. Without this, players cannot upload
   listing photos. (Listings still work text-only.)

4. **Start order.** All resources LB-Phone uses must start **before** lb-phone, and custom
   apps must start **after** it. In `server.cfg`:

   ```
   ensure qb-core
   ensure oxmysql
   ensure ox_inventory      # or your inventory
   ensure lb-phone
   ensure wheeldeal         # AFTER lb-phone
   ```

5. **Admin permissions.** For the admin commands, either rely on the QBCore `admin`
   permission (default) or add an ACE:

   ```
   add_ace group.admin wheeldeal.admin allow
   ```

6. **Verify your vehicle table.** This resource reads/writes `player_vehicles`. The default
   column mapping in `config.lua → Config.VehicleTable` matches stock QBCore
   (`citizenid`, `license`, `plate`, `vehicle`, `garage`, `state`, `financetime`). If your
   schema is customised, update that mapping.

7. **Set the sale garage.** `Config.GarageOnSale` (default `pillboxgarage`) must be a valid
   garage in your garage script — bought vehicles are parked there as stored (`state = 1`).

That's it. The app registers itself with LB-Phone on start (and re-registers if lb-phone
restarts). It appears on the phone automatically because `Config.DefaultApp = true`.

---

## Configuration highlights (`config.lua`)

- **Economy:** `BuyerAccount` / `SellerAccount` (`bank` or `cash`), `MinPrice`, `MaxPrice`,
  optional non-refundable `ListingFee`.
- **Listings:** `MaxImagesPerListing`, `MaxActiveListings`, `ListingDurationDays`,
  `ExpireCheckMinutes`, and text-length caps.
- **Vehicles:** `GarageOnSale`, `StateOnSale`, `BlockFinancedSales`, and the
  `VehicleTable` column map.
- **Categories:** edit `Config.Categories`; toggle `AllowEmergencyCategory`. `CategoryMap`
  controls which marketplace category is pre-selected from a vehicle's QBCore category.
- **Image security:** `AllowedImageDomains` — leave empty to accept any `https` URL, or lock
  it to your upload host(s) to prevent image injection.
- **Admin:** command names and permission settings under `Config.Admin`.
- **Notifications:** per-event toggles under `Config.Notify`.

---

## Admin commands

Run in-game (as an admin) or from the server console:

| Command | Description |
| --- | --- |
| `/wd_remove [listingId]` | Remove a listing from the marketplace |
| `/wd_listings` | Print the 50 most recent listings to console |
| `/wd_sales` | Print the 50 most recent sales to console |
| `/wd_ban [citizenid] [reason]` | Ban a citizen from the marketplace (also removes their active listings) |
| `/wd_unban [citizenid]` | Lift a marketplace ban |

---

## Security & performance notes

- **All validation is server-side.** Ownership, funds, prices, categories, and image URLs are
  re-checked on the server; the UI is never trusted. All queries are parameterised.
- **No duplicate sales / double transfers.** The sale claims the listing with a conditional
  `status = 'active' → 'sold'` update and transfers the vehicle with the `WHERE` clause pinned
  to the current owner, both checked by affected-row count, with rollback on failure.
- **Offline-safe money.** Paying a seller or charging a buyer works whether they are online
  (QBCore money functions) or offline (direct `players.money` JSON update).
- **Efficient queries.** Cover images are fetched in a single batched query (no N+1), listing
  pages use indexed sort/filter columns, and pagination fetches `perPage + 1` to detect more
  pages without a separate count.

---

## Known limitations / things to be aware of

- **Physical vehicle in the world.** A sale changes database ownership and garage/state. It
  does **not** force-despawn a vehicle that the seller currently has spawned in the world.
  Ownership has transferred, so once the car is stored it goes to the buyer; if you want the
  entity removed immediately, add an integration with your garage script in `completeSale`.
- **Custom banking resources.** Offline money uses the standard `players.money` JSON column.
  If you use a banking system that stores money elsewhere, adjust the money helpers in
  `server/sv_utils.lua`.
- **Stored phone numbers.** Call/Message use the seller's number captured when the listing was
  created (and the buyer's when an offer is made). If a player changes their number, stored
  values may be stale.
- **Message Seller** sends a canned inquiry from the buyer to the seller via LB-Phone's
  `SendMessage` and opens that thread. Edit the message text in
  `server/sv_main.lua → wheeldeal:server:messageSeller`.
- **Categories** are chosen by the seller (auto-suggested from the vehicle's QBCore category),
  since spawn codes don't reliably map to a single marketplace category.

---

## File overview

```
wheeldeal/
├── fxmanifest.lua
├── config.lua            -- all settings (shared)
├── install.sql           -- database schema
├── client/
│   └── client.lua        -- registers the app, bridges UI <-> server callbacks
├── server/
│   ├── sv_utils.lua      -- QBCore bridge, money/vehicle/identity helpers, validation
│   └── sv_main.lua       -- callbacks, atomic sale logic, offers, expiry, admin
└── ui/
    ├── index.html
    ├── colors.css        -- theme tokens (dark/light)
    ├── styles.css        -- all component styles (rem/em for fixBlur)
    ├── app.js            -- the marketplace app
    ├── dev.js            -- browser preview only (ignored in-game)
    └── assets/icon.svg
```

To preview the UI in a browser during development, open `ui/index.html` directly — `dev.js`
builds a phone frame and feeds the app mock data.
