--[[ wheeldeal / server / sv_utils.lua
     Shared server-side helpers. Everything that touches money, ownership or
     identity lives here and works whether the target player is ONLINE or OFFLINE.
     All DB access is parameterised (no string concatenation) to prevent injection.
]]

QBCore = exports['qb-core']:GetCoreObject()

Util = {}

local VT = Config.VehicleTable

------------------------------------------------------------------------
-- IDENTITY
------------------------------------------------------------------------

--- Resolve the citizenid for a connected source.
function Util.GetCitizenId(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return nil end
    return Player.PlayerData.citizenid
end

--- Pretty character name for a citizenid (online or offline).
function Util.GetCharName(citizenid)
    local Player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if Player then
        local ci = Player.PlayerData.charinfo
        return ('%s %s'):format(ci.firstname or '', ci.lastname or ''):gsub('^%s+', ''):gsub('%s+$', '')
    end
    local row = MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ?', { citizenid })
    if row and row.charinfo then
        local ci = json.decode(row.charinfo)
        if ci then
            return ('%s %s'):format(ci.firstname or '', ci.lastname or '')
        end
    end
    return 'Unknown'
end

--- License/identifier stored on player_vehicles for a citizenid (online or offline).
function Util.GetLicense(citizenid)
    local Player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if Player then return Player.PlayerData.license end
    return MySQL.scalar.await('SELECT license FROM players WHERE citizenid = ?', { citizenid })
end

--- Equipped LB-Phone number for a connected source (best-effort).
function Util.GetPhoneNumber(src)
    local ok, number = pcall(function()
        return exports['lb-phone']:GetEquippedPhoneNumber(src)
    end)
    if ok and number then return number end
    return nil
end

--- Source for a citizenid if they are currently online, else nil.
function Util.GetSource(citizenid)
    local Player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    return Player and Player.PlayerData.source or nil
end

------------------------------------------------------------------------
-- MONEY (online + offline safe)
------------------------------------------------------------------------

--- Read an account balance for a citizenid.
function Util.GetMoney(citizenid, account)
    local Player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if Player then
        return Player.PlayerData.money[account] or 0
    end
    local row = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', { citizenid })
    if not row or not row.money then return 0 end
    local money = json.decode(row.money) or {}
    return money[account] or 0
end

--- Add money to a citizenid. Returns true on success.
function Util.AddMoney(citizenid, account, amount, reason)
    if amount <= 0 then return true end
    local Player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if Player then
        return Player.Functions.AddMoney(account, amount, reason or 'wheeldeal')
    end
    -- offline: mutate the players.money JSON directly
    local row = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', { citizenid })
    if not row then return false end
    local money = json.decode(row.money) or {}
    money[account] = (money[account] or 0) + amount
    local affected = MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?',
        { json.encode(money), citizenid })
    return affected ~= nil and affected > 0
end

--- Remove money from a citizenid only if they can afford it. Returns true on success.
function Util.RemoveMoney(citizenid, account, amount, reason)
    if amount <= 0 then return true end
    local Player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    if Player then
        if (Player.PlayerData.money[account] or 0) < amount then return false end
        return Player.Functions.RemoveMoney(account, amount, reason or 'wheeldeal')
    end
    -- offline
    local row = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', { citizenid })
    if not row then return false end
    local money = json.decode(row.money) or {}
    if (money[account] or 0) < amount then return false end
    money[account] = money[account] - amount
    local affected = MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?',
        { json.encode(money), citizenid })
    return affected ~= nil and affected > 0
end

------------------------------------------------------------------------
-- VEHICLES
------------------------------------------------------------------------

--- All vehicles owned by a citizenid, enriched with QBCore shared display data.
function Util.GetOwnedVehicles(citizenid)
    local q = ([[SELECT `%s` AS plate, `%s` AS model, `%s` AS garage, `%s` AS state %s
                 FROM `%s` WHERE `%s` = ?]]):format(
        VT.plate, VT.model, VT.garage, VT.state,
        VT.financetime and (', `' .. VT.financetime .. '` AS financetime') or '',
        VT.name, VT.owner)
    local rows = MySQL.query.await(q, { citizenid }) or {}

    -- Plates already on an active listing (so the UI can grey them out)
    local listed = {}
    local active = MySQL.query.await(
        'SELECT plate FROM wheeldeal_listings WHERE seller_citizenid = ? AND status = "active"',
        { citizenid }) or {}
    for _, r in ipairs(active) do listed[r.plate] = true end

    local result = {}
    for _, v in ipairs(rows) do
        local shared = QBCore.Shared.Vehicles[v.model]
        local label  = shared and shared.name or v.model
        local brand  = shared and shared.brand or ''
        local cat    = shared and Config.CategoryMap[shared.category] or 'cars'
        result[#result + 1] = {
            plate        = v.plate,
            model        = v.model,
            label        = label,
            brand        = brand,
            suggestedCat = cat,
            garage       = v.garage,
            financed     = (VT.financetime and v.financetime and v.financetime > 0) or false,
            alreadyListed= listed[v.plate] == true,
        }
    end
    return result
end

--- Authoritative ownership check.
function Util.OwnsPlate(citizenid, plate)
    local cnt = MySQL.scalar.await(
        ('SELECT COUNT(1) FROM `%s` WHERE `%s` = ? AND `%s` = ?'):format(VT.name, VT.plate, VT.owner),
        { plate, citizenid })
    return (cnt or 0) > 0
end

--- Is this vehicle still financed (owes payments)?
function Util.IsFinanced(plate)
    if not VT.financetime then return false end
    local ft = MySQL.scalar.await(
        ('SELECT `%s` FROM `%s` WHERE `%s` = ?'):format(VT.financetime, VT.name, VT.plate),
        { plate })
    return (ft or 0) > 0
end

--- Atomically reassign a vehicle from one owner to another.
--- The WHERE clause pins the CURRENT owner so a vehicle can never be transferred
--- twice or stolen out from under a concurrent sale. Returns affected row count.
function Util.TransferVehicle(plate, fromCid, toCid, toLicense)
    local q = ([[UPDATE `%s`
                 SET `%s` = ?, `%s` = ?, `%s` = ?, `%s` = ?
                 WHERE `%s` = ? AND `%s` = ?]]):format(
        VT.name,
        VT.owner, VT.license, VT.state, VT.garage,
        VT.plate, VT.owner)
    return MySQL.update.await(q, {
        toCid, toLicense, Config.StateOnSale, Config.GarageOnSale,
        plate, fromCid
    }) or 0
end

------------------------------------------------------------------------
-- VALIDATION
------------------------------------------------------------------------

function Util.IsValidImageUrl(url)
    if type(url) ~= 'string' then return false end
    if #url == 0 or #url > Config.MaxImageUrlLength then return false end
    if not url:match('^https?://') then return false end
    if #Config.AllowedImageDomains > 0 then
        local host = url:match('^https?://([^/]+)')
        if not host then return false end
        for _, domain in ipairs(Config.AllowedImageDomains) do
            if host == domain or host:sub(-(#domain + 1)) == ('.' .. domain) then
                return true
            end
        end
        return false
    end
    return true
end

--- Clamp & sanitise free text fields.
function Util.Clean(str, maxLen)
    if type(str) ~= 'string' then return '' end
    str = str:gsub('%c', ' ')               -- strip control chars
    if #str > maxLen then str = str:sub(1, maxLen) end
    return str:gsub('^%s+', ''):gsub('%s+$', '')
end

--- Coerce to a safe positive integer within bounds.
function Util.ToInt(v, min, max)
    local n = math.floor(tonumber(v) or 0)
    if n < min then n = min end
    if n > max then n = max end
    return n
end

function Util.IsBanned(citizenid)
    local cnt = MySQL.scalar.await('SELECT COUNT(1) FROM wheeldeal_bans WHERE citizenid = ?', { citizenid })
    return (cnt or 0) > 0
end

------------------------------------------------------------------------
-- ADMIN
------------------------------------------------------------------------

function Util.IsAdmin(src)
    if Config.Admin.useAce and IsPlayerAceAllowed(src, Config.Admin.acePermission) then
        return true
    end
    if Config.Admin.useQBPermission then
        local ok = QBCore.Functions.HasPermission(src, Config.Admin.qbPermission)
        if ok then return true end
    end
    return false
end

------------------------------------------------------------------------
-- NOTIFICATIONS  (fires an LB-Phone notification on the target's phone)
------------------------------------------------------------------------

function Util.Notify(citizenid, title, content)
    local src = Util.GetSource(citizenid)
    if not src then return end          -- offline: they'll see it in-app next open
    -- LB-Phone server export: SendNotification(target, data). `app` ties the
    -- notification to our custom app so it shows the AutoTrader LS icon.
    pcall(function()
        exports['lb-phone']:SendNotification(src, {
            app     = Config.Identifier,
            title   = title,
            content = content,
        })
    end)
end
