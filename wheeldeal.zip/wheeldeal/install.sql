-- =====================================================================
--  AutoTrader LS (wheeldeal) - database schema
--  Run this once on your server database (import via HeidiSQL / phpMyAdmin
--  or let oxmysql run it). Safe to re-run (IF NOT EXISTS).
-- =====================================================================

-- ----- Listings -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wheeldeal_listings` (
    `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `seller_citizenid`  VARCHAR(64)  NOT NULL,
    `seller_name`       VARCHAR(128) NOT NULL,
    `seller_number`     VARCHAR(32)  DEFAULT NULL,
    `plate`             VARCHAR(16)  NOT NULL,
    `model`             VARCHAR(64)  NOT NULL,
    `title`             VARCHAR(64)  NOT NULL,
    `category`          VARCHAR(32)  NOT NULL DEFAULT 'cars',
    `price`             BIGINT UNSIGNED NOT NULL,
    `mileage`           INT UNSIGNED NOT NULL DEFAULT 0,
    `condition_rating`  TINYINT UNSIGNED NOT NULL DEFAULT 5,
    `description`       TEXT         DEFAULT NULL,
    `contact_notes`     VARCHAR(160) DEFAULT NULL,
    `status`            ENUM('active','sold','expired','removed') NOT NULL DEFAULT 'active',
    `created_at`        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `expires_at`        TIMESTAMP    NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_status`          (`status`),
    KEY `idx_seller`          (`seller_citizenid`),
    KEY `idx_plate`           (`plate`),
    KEY `idx_category`        (`category`),
    KEY `idx_status_created`  (`status`, `created_at`),
    KEY `idx_status_price`    (`status`, `price`),
    KEY `idx_status_mileage`  (`status`, `mileage`),
    KEY `idx_expires`         (`status`, `expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----- Images (multiple per listing, ordered) ------------------------
CREATE TABLE IF NOT EXISTS `wheeldeal_images` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `listing_id`  INT UNSIGNED NOT NULL,
    `url`         VARCHAR(512) NOT NULL,
    `position`    TINYINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `idx_listing` (`listing_id`),
    KEY `idx_listing_pos` (`listing_id`, `position`),
    CONSTRAINT `fk_wd_images_listing`
        FOREIGN KEY (`listing_id`) REFERENCES `wheeldeal_listings` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----- Favorites ------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wheeldeal_favorites` (
    `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `citizenid`   VARCHAR(64)  NOT NULL,
    `listing_id`  INT UNSIGNED NOT NULL,
    `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uniq_fav` (`citizenid`, `listing_id`),
    KEY `idx_citizen` (`citizenid`),
    CONSTRAINT `fk_wd_fav_listing`
        FOREIGN KEY (`listing_id`) REFERENCES `wheeldeal_listings` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----- Offers ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wheeldeal_offers` (
    `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `listing_id`       INT UNSIGNED NOT NULL,
    `buyer_citizenid`  VARCHAR(64)  NOT NULL,
    `buyer_name`       VARCHAR(128) NOT NULL,
    `buyer_number`     VARCHAR(32)  DEFAULT NULL,
    `amount`           BIGINT UNSIGNED NOT NULL,
    `counter_amount`   BIGINT UNSIGNED DEFAULT NULL,
    `status`           ENUM('pending','accepted','declined','countered','withdrawn') NOT NULL DEFAULT 'pending',
    `created_at`       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_listing` (`listing_id`),
    KEY `idx_buyer`   (`buyer_citizenid`),
    KEY `idx_status`  (`status`),
    KEY `idx_listing_status` (`listing_id`, `status`),
    CONSTRAINT `fk_wd_offer_listing`
        FOREIGN KEY (`listing_id`) REFERENCES `wheeldeal_listings` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----- Sales history (immutable ledger, never cascade-deleted) --------
CREATE TABLE IF NOT EXISTS `wheeldeal_sales` (
    `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `listing_id`        INT UNSIGNED DEFAULT NULL,
    `plate`             VARCHAR(16)  NOT NULL,
    `model`             VARCHAR(64)  NOT NULL,
    `seller_citizenid`  VARCHAR(64)  NOT NULL,
    `buyer_citizenid`   VARCHAR(64)  NOT NULL,
    `price`             BIGINT UNSIGNED NOT NULL,
    `via`               ENUM('buy_now','offer','counter') NOT NULL DEFAULT 'buy_now',
    `sold_at`           TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_seller` (`seller_citizenid`),
    KEY `idx_buyer`  (`buyer_citizenid`),
    KEY `idx_plate`  (`plate`),
    KEY `idx_sold_at`(`sold_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----- Reports --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `wheeldeal_reports` (
    `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `listing_id`          INT UNSIGNED NOT NULL,
    `reporter_citizenid`  VARCHAR(64)  NOT NULL,
    `reason`              VARCHAR(255) NOT NULL,
    `handled`             TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_listing` (`listing_id`),
    KEY `idx_handled` (`handled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----- Marketplace bans ----------------------------------------------
CREATE TABLE IF NOT EXISTS `wheeldeal_bans` (
    `citizenid`  VARCHAR(64)  NOT NULL,
    `reason`     VARCHAR(255) DEFAULT NULL,
    `banned_by`  VARCHAR(64)  DEFAULT NULL,
    `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
