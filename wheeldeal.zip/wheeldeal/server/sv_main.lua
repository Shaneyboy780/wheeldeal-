--[[ wheeldeal / server / sv_main.lua
     All marketplace logic. The client only ever sends intent; this file decides
     what is allowed and performs every money/ownership change itself.
]]

local PER_PAGE_MAX = 20
local warnedExpiry = {}            -- listingId -> true (expiry warning sent this session)
local cooldowns    = {}            -- src -> { action -> os.clock() }

------------------------------------------------------------------------
-- small helpers
------------------------------------------------------------------------
local function fmt(n)
    local s = tostring(math.floor(n))
    local out = s:reverse():gsub('(%d%d%d)', '%1,'):reverse()
    return (Config.Currency) .. (out:gsub('^,', ''))
end

local function onCooldown(src, action)
    local now = os.clock()
    cooldowns[src] = cooldowns[src] or {}
    local last = cooldowns[src][action]
    local wait = (Config.Cooldowns[action] or 0)
    if last and (now - last) < wait then return true end
    cooldowns[src][action] = now
    return false
end

local function validCategory(key)
    for _, c in ipairs(Config.Categories) do
        if c.key == key then return true end
    end
    return false
end

local SORTS = {
    price_asc    = '`price` ASC',
    price_desc   = '`price` DESC',
    newest       = '`created_at` DESC',
    oldest       = '`created_at` ASC',
    mileage_asc  = '`mileage` ASC',
    mileage_desc = '`mileage` DESC',
}

-- Fetch one cover image per listing id (single query, no N+1).
local function getCovers(ids)
    if #ids == 0 then return {} end
    local ph = {}
    for i = 1, #ids do ph[i] = '?' end
    local list = table.concat(ph, ',')
    local rows = MySQL.query.await(([[
        SELECT i.listing_id AS id, i.url AS url
        FROM wheeldeal_images i
        INNER JOIN (
            SELECT listing_id, MIN(position) AS p
            FROM wheeldeal_images WHERE listing_id IN (%s) GROUP BY listing_id
        ) m ON i.listing_id = m.listing_id AND i.position = m.p
    ]]):format(list), ids) or {}
    local map = {}
    for _, r in ipairs(rows) do map[r.id] = r.url end
    return map
end

------------------------------------------------------------------------
-- CORE: complete a sale (shared by Buy Now, accepted offers, counters)
-- Returns success(boolean), message(string)
------------------------------------------------------------------------
local function completeSale(listingId, buyerCid, via, agreedPrice)
    local listing = MySQL.single.await('SELECT * FROM wheeldeal_listings WHERE id = ?', { listingId })
    if not listing or listing.status ~= 'active' then
        return false, 'Listing is no longer available'
    end

    local sellerCid = listing.seller_citizenid
    local plate     = listing.plate
    local price     = math.floor(tonumber(agreedPrice) or listing.price)

    if buyerCid == sellerCid then return false, 'You cannot buy your own listing' end
    if price <= 0 or price > Config.MaxPrice then return false, 'Invalid price' end

    -- seller must still own the vehicle
    if not Util.OwnsPlate(sellerCid, plate) then
        MySQL.update.await('UPDATE wheeldeal_listings SET status = "removed" WHERE id = ?', { listingId })
        return false, 'Seller no longer owns this vehicle'
    end

    -- buyer must be able to pay
    if Util.GetMoney(buyerCid, Config.BuyerAccount) < price then
        return false, 'Insufficient funds'
    end

    -- 1) atomically claim the listing (prevents double sale under race)
    local claimed = MySQL.update.await(
        'UPDATE wheeldeal_listings SET status = "sold" WHERE id = ? AND status = "active"', { listingId })
    if (claimed or 0) ~= 1 then
        return false, 'Listing is no longer available'
    end

    -- 2) transfer the vehicle (pinned to current owner)
    local buyerLicense = Util.GetLicense(buyerCid)
    local moved = Util.TransferVehicle(plate, sellerCid, buyerCid, buyerLicense)
    if moved ~= 1 then
        MySQL.update.await('UPDATE wheeldeal_listings SET status = "active" WHERE id = ?', { listingId })
        return false, 'Vehicle could not be transferred'
    end

    -- 3) take money from buyer
    if not Util.RemoveMoney(buyerCid, Config.BuyerAccount, price, 'wheeldeal-purchase') then
        -- roll back: give the vehicle back and reopen the listing
        Util.TransferVehicle(plate, buyerCid, sellerCid, Util.GetLicense(sellerCid))
        MySQL.update.await('UPDATE wheeldeal_listings SET status = "active" WHERE id = ?', { listingId })
        return false, 'Payment failed'
    end

    -- 4) pay the seller
    if not Util.AddMoney(sellerCid, Config.SellerAccount, price, 'wheeldeal-sale') then
        print(('[wheeldeal] WARNING: failed to pay seller %s %s for listing %d'):format(sellerCid, price, listingId))
    end

    -- 5) ledger + cleanup offers
    MySQL.insert.await([[INSERT INTO wheeldeal_sales
        (listing_id, plate, model, seller_citizenid, buyer_citizenid, price, via)
        VALUES (?,?,?,?,?,?,?)]],
        { listingId, plate, listing.model, sellerCid, buyerCid, price, via })

    MySQL.update.await(
        'UPDATE wheeldeal_offers SET status = "withdrawn" WHERE listing_id = ? AND status IN ("pending","countered")',
        { listingId })

    -- 6) notify
    if Config.Notify.listingSold then
        Util.Notify(sellerCid, 'Vehicle Sold', ('%s sold for %s'):format(listing.title, fmt(price)))
    end
    Util.Notify(buyerCid, 'Purchase Complete', ('You bought %s for %s'):format(listing.title, fmt(price)))

    return true, 'Purchase complete'
end

------------------------------------------------------------------------
-- CALLBACKS
------------------------------------------------------------------------

-- meta / bootstrap data for the UI
QBCore.Functions.CreateCallback('wheeldeal:server:getMeta', function(src, cb)
    local cid = Util.GetCitizenId(src)
    if not cid then return cb(false) end
    cb({
        citizenid    = cid,
        name         = Util.GetCharName(cid),
        number       = Util.GetPhoneNumber(src),
        isAdmin      = Util.IsAdmin(src),
        banned       = Util.IsBanned(cid),
        currency     = Config.Currency,
        categories   = Config.Categories,
        maxImages    = Config.MaxImagesPerListing,
        durationDays = Config.ListingDurationDays,
        minPrice     = Config.MinPrice,
        maxPrice     = Config.MaxPrice,
    })
end)

-- vehicles the player personally owns
QBCore.Functions.CreateCallback('wheeldeal:server:getMyVehicles', function(src, cb)
    local cid = Util.GetCitizenId(src)
    if not cid then return cb({}) end
    cb(Util.GetOwnedVehicles(cid))
end)

-- public marketplace
QBCore.Functions.CreateCallback('wheeldeal:server:getListings', function(src, cb, data)
    data = data or {}
    local where, params = { 'status = "active"' }, {}

    if data.category and data.category ~= 'all' and validCategory(data.category) then
        where[#where + 1] = 'category = ?'
        params[#params + 1] = data.category
    end
    if type(data.search) == 'string' and #data.search > 0 then
        local s = '%' .. data.search:gsub('[%%_\\]', '\\%1') .. '%'
        where[#where + 1] = '(title LIKE ? ESCAPE \'\\\\\' OR model LIKE ? ESCAPE \'\\\\\')'
        params[#params + 1] = s
        params[#params + 1] = s
    end
    if type(data.seller) == 'string' and #data.seller > 0 then
        local s = '%' .. data.seller:gsub('[%%_\\]', '\\%1') .. '%'
        where[#where + 1] = 'seller_name LIKE ? ESCAPE \'\\\\\''
        params[#params + 1] = s
    end

    local order   = SORTS[data.sort] or SORTS.newest
    local perPage = math.min(tonumber(data.perPage) or PER_PAGE_MAX, PER_PAGE_MAX)
    local page    = math.max(tonumber(data.page) or 1, 1)
    local offset  = (page - 1) * perPage

    -- fetch one extra row to know if there's a next page
    local q = ([[SELECT id, title, model, category, price, mileage, condition_rating, seller_name, created_at
                 FROM wheeldeal_listings WHERE %s ORDER BY %s LIMIT %d OFFSET %d]])
        :format(table.concat(where, ' AND '), order, perPage + 1, offset)
    local rows = MySQL.query.await(q, params) or {}

    local hasMore = #rows > perPage
    if hasMore then rows[#rows] = nil end

    local ids = {}
    for _, r in ipairs(rows) do ids[#ids + 1] = r.id end
    local covers = getCovers(ids)
    for _, r in ipairs(rows) do r.cover = covers[r.id] end

    cb({ listings = rows, page = page, hasMore = hasMore })
end)

-- single listing detail
QBCore.Functions.CreateCallback('wheeldeal:server:getListing', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb(false) end

    local listing = MySQL.single.await('SELECT * FROM wheeldeal_listings WHERE id = ?', { id })
    if not listing then return cb(false) end

    local images = MySQL.query.await(
        'SELECT url FROM wheeldeal_images WHERE listing_id = ? ORDER BY position ASC', { id }) or {}
    local imgs = {}
    for _, r in ipairs(images) do imgs[#imgs + 1] = r.url end

    local favCount = 0
    pcall(function()
        favCount = MySQL.scalar.await(
            'SELECT COUNT(1) FROM wheeldeal_favorites WHERE citizenid = ? AND listing_id = ?', { cid, id }) or 0
    end)

    -- the viewer's own live offer (lets a buyer see/accept a counter)
    local myOffer
    pcall(function()
        myOffer = MySQL.single.await([[SELECT id, amount, counter_amount, status
            FROM wheeldeal_offers
            WHERE listing_id = ? AND buyer_citizenid = ? AND status IN ('pending','countered')
            ORDER BY created_at DESC LIMIT 1]], { id, cid })
    end)

    local shared = QBCore.Shared.Vehicles[listing.model]
    cb({
        id          = listing.id,
        title       = listing.title,
        model       = listing.model,
        modelLabel  = shared and shared.name or listing.model,
        brand       = shared and shared.brand or '',
        category    = listing.category,
        plate       = listing.plate,
        price       = listing.price,
        mileage     = listing.mileage,
        condition   = listing.condition_rating,
        description = listing.description,
        contact     = listing.contact_notes,
        sellerName  = listing.seller_name,
        sellerNumber= listing.seller_number,
        createdAt   = listing.created_at,
        status      = listing.status,
        images      = imgs,
        isFavorite  = (favCount or 0) > 0,
        isOwner     = listing.seller_citizenid == cid,
        myOffer     = myOffer or nil,
    })
end)

-- create a listing
QBCore.Functions.CreateCallback('wheeldeal:server:createListing', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    if not cid then return cb({ success = false, message = 'Player not found' }) end
    if Util.IsBanned(cid) then return cb({ success = false, message = 'You are banned from the marketplace' }) end
    if onCooldown(src, 'createListing') then return cb({ success = false, message = 'Slow down a moment' }) end

    local plate = data and data.plate
    if type(plate) ~= 'string' or #plate == 0 then
        return cb({ success = false, message = 'No vehicle selected' })
    end

    -- ownership is authoritative
    if not Util.OwnsPlate(cid, plate) then
        return cb({ success = false, message = 'You do not own that vehicle' })
    end
    if Config.BlockFinancedSales and Util.IsFinanced(plate) then
        return cb({ success = false, message = 'This vehicle still has finance owing' })
    end

    -- no duplicate active listing for the same plate
    local dupe = MySQL.scalar.await(
        'SELECT COUNT(1) FROM wheeldeal_listings WHERE plate = ? AND status = "active"', { plate })
    if (dupe or 0) > 0 then
        return cb({ success = false, message = 'That vehicle is already listed' })
    end

    -- listing cap
    if Config.MaxActiveListings > 0 then
        local active = MySQL.scalar.await(
            'SELECT COUNT(1) FROM wheeldeal_listings WHERE seller_citizenid = ? AND status = "active"', { cid })
        if (active or 0) >= Config.MaxActiveListings then
            return cb({ success = false, message = 'You have reached your active listing limit' })
        end
    end

    -- pull the real model from the DB (never trust the client)
    local VT = Config.VehicleTable
    local model = MySQL.scalar.await(
        ('SELECT `%s` FROM `%s` WHERE `%s` = ? AND `%s` = ?'):format(VT.model, VT.name, VT.plate, VT.owner),
        { plate, cid })
    if not model then return cb({ success = false, message = 'Vehicle data not found' }) end

    local shared    = QBCore.Shared.Vehicles[model]
    local price     = Util.ToInt(data.price, Config.MinPrice, Config.MaxPrice)
    local mileage   = Util.ToInt(data.mileage, 0, 9999999)
    local condition = Util.ToInt(data.condition, 1, 5)
    local title     = Util.Clean(data.title, Config.MaxTitleLength)
    if #title == 0 then title = shared and shared.name or model end
    local desc      = Util.Clean(data.description, Config.MaxDescriptionLength)
    local contact   = Util.Clean(data.contactNotes, Config.MaxContactLength)
    local category  = (type(data.category) == 'string' and validCategory(data.category)) and data.category or 'cars'

    -- validate images
    local images = {}
    if type(data.images) == 'table' then
        for _, url in ipairs(data.images) do
            if Util.IsValidImageUrl(url) then
                images[#images + 1] = url
                if #images >= Config.MaxImagesPerListing then break end
            end
        end
    end

    -- optional listing fee
    if Config.ListingFee.enabled and Config.ListingFee.amount > 0 then
        if not Util.RemoveMoney(cid, Config.ListingFee.account, Config.ListingFee.amount, 'wheeldeal-listing-fee') then
            return cb({ success = false, message = 'You cannot afford the listing fee' })
        end
    end

    local expiresExpr = 'NULL'
    if Config.ListingDurationDays > 0 then
        expiresExpr = ('DATE_ADD(NOW(), INTERVAL %d DAY)'):format(Config.ListingDurationDays)
    end

    local id = MySQL.insert.await(([[INSERT INTO wheeldeal_listings
        (seller_citizenid, seller_name, seller_number, plate, model, title, category,
         price, mileage, condition_rating, description, contact_notes, expires_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?, %s)]]):format(expiresExpr),
        { cid, Util.GetCharName(cid), Util.GetPhoneNumber(src), plate, model, title, category,
          price, mileage, condition, desc, contact })

    if not id then return cb({ success = false, message = 'Could not create listing' }) end

    for i, url in ipairs(images) do
        MySQL.insert.await('INSERT INTO wheeldeal_images (listing_id, url, position) VALUES (?,?,?)',
            { id, url, i - 1 })
    end

    cb({ success = true, id = id })
end)

-- edit a listing (owner only)
QBCore.Functions.CreateCallback('wheeldeal:server:editListing', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false, message = 'Invalid request' }) end

    local listing = MySQL.single.await(
        'SELECT seller_citizenid, status FROM wheeldeal_listings WHERE id = ?', { id })
    if not listing or listing.seller_citizenid ~= cid then
        return cb({ success = false, message = 'Not your listing' })
    end
    if listing.status ~= 'active' then
        return cb({ success = false, message = 'Listing is not active' })
    end

    local price     = Util.ToInt(data.price, Config.MinPrice, Config.MaxPrice)
    local mileage   = Util.ToInt(data.mileage, 0, 9999999)
    local condition = Util.ToInt(data.condition, 1, 5)
    local title     = Util.Clean(data.title, Config.MaxTitleLength)
    local desc      = Util.Clean(data.description, Config.MaxDescriptionLength)
    local contact   = Util.Clean(data.contactNotes, Config.MaxContactLength)
    local category  = (type(data.category) == 'string' and validCategory(data.category)) and data.category or 'cars'
    if #title == 0 then return cb({ success = false, message = 'Title required' }) end

    MySQL.update.await([[UPDATE wheeldeal_listings
        SET price = ?, mileage = ?, condition_rating = ?, title = ?, description = ?, contact_notes = ?, category = ?
        WHERE id = ? AND seller_citizenid = ?]],
        { price, mileage, condition, title, desc, contact, category, id, cid })

    cb({ success = true })
end)

-- remove a listing (owner only)
QBCore.Functions.CreateCallback('wheeldeal:server:removeListing', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false }) end
    local affected = MySQL.update.await(
        'UPDATE wheeldeal_listings SET status = "removed" WHERE id = ? AND seller_citizenid = ? AND status = "active"',
        { id, cid })
    cb({ success = (affected or 0) > 0 })
end)

-- add images to an existing listing (owner only)
QBCore.Functions.CreateCallback('wheeldeal:server:addImages', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id or type(data.urls) ~= 'table' then return cb({ success = false }) end

    local listing = MySQL.single.await(
        'SELECT seller_citizenid, status FROM wheeldeal_listings WHERE id = ?', { id })
    if not listing or listing.seller_citizenid ~= cid or listing.status ~= 'active' then
        return cb({ success = false, message = 'Not allowed' })
    end

    local count = MySQL.scalar.await('SELECT COUNT(1) FROM wheeldeal_images WHERE listing_id = ?', { id }) or 0
    local nextPos = MySQL.scalar.await('SELECT IFNULL(MAX(position), -1) + 1 FROM wheeldeal_images WHERE listing_id = ?', { id }) or 0

    for _, url in ipairs(data.urls) do
        if count >= Config.MaxImagesPerListing then break end
        if Util.IsValidImageUrl(url) then
            MySQL.insert.await('INSERT INTO wheeldeal_images (listing_id, url, position) VALUES (?,?,?)',
                { id, url, nextPos })
            count = count + 1
            nextPos = nextPos + 1
        end
    end
    cb({ success = true })
end)

-- favorite / unfavorite
QBCore.Functions.CreateCallback('wheeldeal:server:toggleFavorite', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false }) end

    local exists = MySQL.single.await(
        'SELECT id FROM wheeldeal_favorites WHERE citizenid = ? AND listing_id = ?', { cid, id })
    if exists then
        MySQL.update.await('DELETE FROM wheeldeal_favorites WHERE id = ?', { exists.id })
        return cb({ success = true, favorited = false })
    end
    -- make sure the listing exists before inserting (FK would error otherwise)
    local ok = MySQL.scalar.await('SELECT COUNT(1) FROM wheeldeal_listings WHERE id = ?', { id })
    if (ok or 0) == 0 then return cb({ success = false }) end
    MySQL.insert.await('INSERT INTO wheeldeal_favorites (citizenid, listing_id) VALUES (?,?)', { cid, id })
    cb({ success = true, favorited = true })
end)

-- saved listings
QBCore.Functions.CreateCallback('wheeldeal:server:getFavorites', function(src, cb)
    local cid = Util.GetCitizenId(src)
    if not cid then return cb({}) end
    local rows = MySQL.query.await([[
        SELECT l.id, l.title, l.model, l.category, l.price, l.mileage, l.condition_rating,
               l.seller_name, l.status, l.created_at
        FROM wheeldeal_favorites f
        INNER JOIN wheeldeal_listings l ON l.id = f.listing_id
        WHERE f.citizenid = ?
        ORDER BY f.created_at DESC]], { cid }) or {}
    local ids = {}
    for _, r in ipairs(rows) do ids[#ids + 1] = r.id end
    local covers = getCovers(ids)
    for _, r in ipairs(rows) do r.cover = covers[r.id] end
    cb(rows)
end)

-- seller dashboard
QBCore.Functions.CreateCallback('wheeldeal:server:getDashboard', function(src, cb)
    local cid = Util.GetCitizenId(src)
    if not cid then return cb(false) end

    local active = MySQL.query.await([[
        SELECT l.id, l.title, l.model, l.price, l.mileage, l.condition_rating, l.created_at, l.expires_at,
               (SELECT COUNT(1) FROM wheeldeal_offers o WHERE o.listing_id = l.id AND o.status = 'pending') AS offerCount
        FROM wheeldeal_listings l
        WHERE l.seller_citizenid = ? AND l.status = 'active'
        ORDER BY l.created_at DESC]], { cid }) or {}

    local sold = MySQL.query.await([[
        SELECT l.id, l.title, l.model, s.price, s.sold_at, s.via
        FROM wheeldeal_sales s
        INNER JOIN wheeldeal_listings l ON l.id = s.listing_id
        WHERE s.seller_citizenid = ?
        ORDER BY s.sold_at DESC LIMIT 50]], { cid }) or {}

    local expired = MySQL.query.await([[
        SELECT id, title, model, price, created_at, expires_at
        FROM wheeldeal_listings
        WHERE seller_citizenid = ? AND status = 'expired'
        ORDER BY expires_at DESC LIMIT 50]], { cid }) or {}

    local offers = MySQL.query.await([[
        SELECT o.id, o.listing_id, o.buyer_name, o.amount, o.counter_amount, o.status, o.created_at, l.title
        FROM wheeldeal_offers o
        INNER JOIN wheeldeal_listings l ON l.id = o.listing_id
        WHERE l.seller_citizenid = ? AND o.status IN ('pending','countered')
        ORDER BY o.created_at DESC]], { cid }) or {}

    local activeIds = {}
    for _, r in ipairs(active) do activeIds[#activeIds + 1] = r.id end
    local covers = getCovers(activeIds)
    for _, r in ipairs(active) do r.cover = covers[r.id] end

    cb({ active = active, sold = sold, expired = expired, offers = offers })
end)

-- relist an expired listing (owner only)
QBCore.Functions.CreateCallback('wheeldeal:server:relist', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false }) end

    local listing = MySQL.single.await(
        'SELECT seller_citizenid, plate, status FROM wheeldeal_listings WHERE id = ?', { id })
    if not listing or listing.seller_citizenid ~= cid or listing.status ~= 'expired' then
        return cb({ success = false, message = 'Cannot relist' })
    end
    if not Util.OwnsPlate(cid, listing.plate) then
        return cb({ success = false, message = 'You no longer own that vehicle' })
    end

    local expiresExpr = Config.ListingDurationDays > 0
        and ('DATE_ADD(NOW(), INTERVAL %d DAY)'):format(Config.ListingDurationDays) or 'NULL'
    MySQL.update.await(('UPDATE wheeldeal_listings SET status = "active", created_at = NOW(), expires_at = %s WHERE id = ?')
        :format(expiresExpr), { id })
    warnedExpiry[id] = nil
    cb({ success = true })
end)

-- BUY NOW
QBCore.Functions.CreateCallback('wheeldeal:server:purchase', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false, message = 'Invalid request' }) end
    if Util.IsBanned(cid) then return cb({ success = false, message = 'You are banned from the marketplace' }) end
    local ok, msg = completeSale(id, cid, 'buy_now', nil)
    cb({ success = ok, message = msg })
end)

-- submit / update an offer
QBCore.Functions.CreateCallback('wheeldeal:server:submitOffer', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false, message = 'Invalid request' }) end
    if Util.IsBanned(cid) then return cb({ success = false, message = 'You are banned from the marketplace' }) end
    if onCooldown(src, 'submitOffer') then return cb({ success = false, message = 'Slow down a moment' }) end

    local amount = Util.ToInt(data.amount, 1, Config.MaxPrice)
    local listing = MySQL.single.await(
        'SELECT seller_citizenid, title, status FROM wheeldeal_listings WHERE id = ?', { id })
    if not listing or listing.status ~= 'active' then
        return cb({ success = false, message = 'Listing is not available' })
    end
    if listing.seller_citizenid == cid then
        return cb({ success = false, message = 'You cannot make an offer on your own listing' })
    end

    -- one live offer per buyer per listing: update if it already exists
    local existing = MySQL.single.await(
        'SELECT id FROM wheeldeal_offers WHERE listing_id = ? AND buyer_citizenid = ? AND status IN ("pending","countered")',
        { id, cid })
    if existing then
        MySQL.update.await('UPDATE wheeldeal_offers SET amount = ?, counter_amount = NULL, status = "pending" WHERE id = ?',
            { amount, existing.id })
    else
        MySQL.insert.await([[INSERT INTO wheeldeal_offers
            (listing_id, buyer_citizenid, buyer_name, buyer_number, amount)
            VALUES (?,?,?,?,?)]],
            { id, cid, Util.GetCharName(cid), Util.GetPhoneNumber(src), amount })
    end

    if Config.Notify.newOffer then
        Util.Notify(listing.seller_citizenid, 'New Offer',
            ('%s offered %s on %s'):format(Util.GetCharName(cid), fmt(amount), listing.title))
    end
    cb({ success = true })
end)

-- seller acts on an offer: accept / decline / counter
QBCore.Functions.CreateCallback('wheeldeal:server:offerAction', function(src, cb, data)
    local cid    = Util.GetCitizenId(src)
    local offerId= tonumber(data and data.offerId)
    local action = data and data.action
    if not cid or not offerId then return cb({ success = false, message = 'Invalid request' }) end

    local offer = MySQL.single.await([[
        SELECT o.*, l.seller_citizenid, l.title, l.status AS listing_status
        FROM wheeldeal_offers o INNER JOIN wheeldeal_listings l ON l.id = o.listing_id
        WHERE o.id = ?]], { offerId })
    if not offer or offer.seller_citizenid ~= cid then
        return cb({ success = false, message = 'Not your offer to manage' })
    end
    if offer.status ~= 'pending' then
        return cb({ success = false, message = 'Offer is no longer pending' })
    end

    if action == 'accept' then
        if offer.listing_status ~= 'active' then
            return cb({ success = false, message = 'Listing is not active' })
        end
        local ok, msg = completeSale(offer.listing_id, offer.buyer_citizenid, 'offer', offer.amount)
        if ok then
            MySQL.update.await('UPDATE wheeldeal_offers SET status = "accepted" WHERE id = ?', { offerId })
            if Config.Notify.offerAccepted then
                Util.Notify(offer.buyer_citizenid, 'Offer Accepted',
                    ('Your %s offer on %s was accepted'):format(fmt(offer.amount), offer.title))
            end
        else
            -- couldn't complete (e.g. buyer broke) -> decline so it doesn't linger
            MySQL.update.await('UPDATE wheeldeal_offers SET status = "declined" WHERE id = ?', { offerId })
            Util.Notify(offer.buyer_citizenid, 'Offer Failed',
                ('Your offer on %s could not be completed: %s'):format(offer.title, msg))
        end
        return cb({ success = ok, message = msg })

    elseif action == 'decline' then
        MySQL.update.await('UPDATE wheeldeal_offers SET status = "declined" WHERE id = ?', { offerId })
        if Config.Notify.offerDeclined then
            Util.Notify(offer.buyer_citizenid, 'Offer Declined',
                ('Your offer on %s was declined'):format(offer.title))
        end
        return cb({ success = true })

    elseif action == 'counter' then
        local counter = Util.ToInt(data.value, 1, Config.MaxPrice)
        MySQL.update.await('UPDATE wheeldeal_offers SET status = "countered", counter_amount = ? WHERE id = ?',
            { counter, offerId })
        if Config.Notify.offerCountered then
            Util.Notify(offer.buyer_citizenid, 'Counter Offer',
                ('Seller countered with %s on %s'):format(fmt(counter), offer.title))
        end
        return cb({ success = true })
    end

    cb({ success = false, message = 'Unknown action' })
end)

-- buyer accepts a counter offer (this charges the buyer)
QBCore.Functions.CreateCallback('wheeldeal:server:acceptCounter', function(src, cb, data)
    local cid     = Util.GetCitizenId(src)
    local offerId = tonumber(data and data.offerId)
    if not cid or not offerId then return cb({ success = false, message = 'Invalid request' }) end

    local offer = MySQL.single.await([[
        SELECT o.*, l.title FROM wheeldeal_offers o
        INNER JOIN wheeldeal_listings l ON l.id = o.listing_id WHERE o.id = ?]], { offerId })
    if not offer or offer.buyer_citizenid ~= cid then
        return cb({ success = false, message = 'Not your offer' })
    end
    if offer.status ~= 'countered' or not offer.counter_amount then
        return cb({ success = false, message = 'No counter to accept' })
    end

    local ok, msg = completeSale(offer.listing_id, cid, 'counter', offer.counter_amount)
    if ok then
        MySQL.update.await('UPDATE wheeldeal_offers SET status = "accepted" WHERE id = ?', { offerId })
        Util.Notify(offer.seller_citizenid, 'Counter Accepted',
            ('Your counter of %s on %s was accepted'):format(fmt(offer.counter_amount), offer.title))
    end
    cb({ success = ok, message = msg })
end)

-- buyer withdraws their own pending offer
QBCore.Functions.CreateCallback('wheeldeal:server:withdrawOffer', function(src, cb, data)
    local cid     = Util.GetCitizenId(src)
    local offerId = tonumber(data and data.offerId)
    if not cid or not offerId then return cb({ success = false }) end
    local affected = MySQL.update.await(
        'UPDATE wheeldeal_offers SET status = "withdrawn" WHERE id = ? AND buyer_citizenid = ? AND status IN ("pending","countered")',
        { offerId, cid })
    cb({ success = (affected or 0) > 0 })
end)

-- report a listing
QBCore.Functions.CreateCallback('wheeldeal:server:reportListing', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false }) end
    local reason = Util.Clean(data.reason, 255)
    if #reason == 0 then reason = 'No reason given' end

    local exists = MySQL.scalar.await(
        'SELECT COUNT(1) FROM wheeldeal_reports WHERE listing_id = ? AND reporter_citizenid = ? AND handled = 0',
        { id, cid })
    if (exists or 0) > 0 then return cb({ success = true }) end -- already reported, silently ok

    MySQL.insert.await(
        'INSERT INTO wheeldeal_reports (listing_id, reporter_citizenid, reason) VALUES (?,?,?)',
        { id, cid, reason })
    cb({ success = true })
end)

-- message the seller (opens a thread in the buyer's Messages app)
QBCore.Functions.CreateCallback('wheeldeal:server:messageSeller', function(src, cb, data)
    local cid = Util.GetCitizenId(src)
    local id  = tonumber(data and data.id)
    if not cid or not id then return cb({ success = false }) end
    if onCooldown(src, 'sendMessage') then return cb({ success = false, message = 'Slow down a moment' }) end

    local listing = MySQL.single.await('SELECT title, seller_number FROM wheeldeal_listings WHERE id = ?', { id })
    if not listing or not listing.seller_number then
        return cb({ success = false, message = 'Seller phone unavailable' })
    end
    local from = Util.GetPhoneNumber(src)
    if not from then return cb({ success = false, message = 'Your phone is unavailable' }) end

    local content = ('Hi! Is your "%s" still available?'):format(listing.title)
    local ok = pcall(function()
        exports['lb-phone']:SendMessage(from, listing.seller_number, content)
    end)
    cb({ success = ok, message = ok and 'Message sent' or 'Could not send message' })
end)

------------------------------------------------------------------------
-- EXPIRATION SWEEP
------------------------------------------------------------------------
CreateThread(function()
    while true do
        if Config.ListingDurationDays > 0 then
            -- expire overdue listings
            MySQL.update.await([[UPDATE wheeldeal_listings
                SET status = 'expired'
                WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= NOW()]])

            -- warn sellers whose listings expire within 24h (once per session)
            if Config.Notify.listingExpiring then
                local soon = MySQL.query.await([[SELECT id, seller_citizenid, title FROM wheeldeal_listings
                    WHERE status = 'active' AND expires_at IS NOT NULL
                      AND expires_at > NOW() AND expires_at <= DATE_ADD(NOW(), INTERVAL 24 HOUR)]]) or {}
                for _, r in ipairs(soon) do
                    if not warnedExpiry[r.id] then
                        warnedExpiry[r.id] = true
                        Util.Notify(r.seller_citizenid, 'Listing Expiring',
                            ('%s expires within 24 hours'):format(r.title))
                    end
                end
            end
        end
        Wait(Config.ExpireCheckMinutes * 60 * 1000)
    end
end)

-- tidy cooldown table on disconnect
AddEventHandler('playerDropped', function()
    cooldowns[source] = nil
end)

------------------------------------------------------------------------
-- ADMIN COMMANDS
------------------------------------------------------------------------
local C = Config.Admin.commands

RegisterCommand(C.removeListing, function(src, args)
    if not Util.IsAdmin(src) then return end
    local id = tonumber(args[1])
    if not id then print('usage: /' .. C.removeListing .. ' [listingId]') return end
    MySQL.update.await('UPDATE wheeldeal_listings SET status = "removed" WHERE id = ?', { id })
    print(('[wheeldeal] listing %d removed by admin'):format(id))
end, false)

RegisterCommand(C.listAll, function(src)
    if not Util.IsAdmin(src) then return end
    local rows = MySQL.query.await([[SELECT id, title, seller_name, price, status, created_at
        FROM wheeldeal_listings ORDER BY created_at DESC LIMIT 50]]) or {}
    print(('[wheeldeal] %d most recent listings:'):format(#rows))
    for _, r in ipairs(rows) do
        print(('  #%d | %s | %s | %s%d | %s'):format(r.id, r.title, r.seller_name, Config.Currency, r.price, r.status))
    end
end, false)

RegisterCommand(C.salesHistory, function(src)
    if not Util.IsAdmin(src) then return end
    local rows = MySQL.query.await([[SELECT id, model, seller_citizenid, buyer_citizenid, price, via, sold_at
        FROM wheeldeal_sales ORDER BY sold_at DESC LIMIT 50]]) or {}
    print(('[wheeldeal] %d most recent sales:'):format(#rows))
    for _, r in ipairs(rows) do
        print(('  #%d | %s | %s -> %s | %s%d | %s'):format(r.id, r.model, r.seller_citizenid, r.buyer_citizenid, Config.Currency, r.price, r.via))
    end
end, false)

RegisterCommand(C.banSeller, function(src, args)
    if not Util.IsAdmin(src) then return end
    local cid = args[1]
    if not cid then print('usage: /' .. C.banSeller .. ' [citizenid] [reason]') return end
    local reason = table.concat(args, ' ', 2)
    if #reason == 0 then reason = 'Marketplace abuse' end
    local by = (src == 0) and 'console' or (Util.GetCitizenId(src) or 'admin')
    MySQL.insert.await('INSERT INTO wheeldeal_bans (citizenid, reason, banned_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE reason = VALUES(reason), banned_by = VALUES(banned_by)',
        { cid, reason, by })
    MySQL.update.await('UPDATE wheeldeal_listings SET status = "removed" WHERE seller_citizenid = ? AND status = "active"', { cid })
    print(('[wheeldeal] %s banned from marketplace (%s)'):format(cid, reason))
end, false)

RegisterCommand(C.unbanSeller, function(src, args)
    if not Util.IsAdmin(src) then return end
    local cid = args[1]
    if not cid then print('usage: /' .. C.unbanSeller .. ' [citizenid]') return end
    MySQL.update.await('DELETE FROM wheeldeal_bans WHERE citizenid = ?', { cid })
    print(('[wheeldeal] %s unbanned from marketplace'):format(cid))
end, false)
