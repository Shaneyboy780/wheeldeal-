--[[ wheeldeal / client/client.lua
     Registers the AutoTrader LS app with LB-Phone and bridges the UI's
     fetchNui(...) calls to QBCore server callbacks. The UI never talks to the
     server directly - everything goes through here, and the server re-validates.
]]

local QBCore     = exports['qb-core']:GetCoreObject()
local identifier = Config.Identifier

------------------------------------------------------------------------
-- Register the app with LB-Phone
------------------------------------------------------------------------
local function addApp()
    local resource = GetCurrentResourceName()

    local images = {}
    if Config.Images and #Config.Images > 0 then
        images = Config.Images
    end

    local added, err = exports['lb-phone']:AddCustomApp({
        identifier  = identifier,
        name        = Config.AppName,
        description = Config.Description,
        developer   = Config.Developer,
        defaultApp  = Config.DefaultApp,
        size        = Config.AppSize,
        images      = images,
        ui          = resource .. '/ui/index.html',
        icon        = ('https://cfx-nui-%s/ui/assets/icon.svg'):format(resource),
        fixBlur     = true, -- our CSS uses rem/em units
    })

    if not added then
        print(('[wheeldeal] Could not add app: %s'):format(err or 'unknown error'))
    end
end

-- Wait for LB-Phone, then register
CreateThread(function()
    while GetResourceState('lb-phone') ~= 'started' do Wait(500) end
    addApp()
end)

-- Re-register if LB-Phone restarts
AddEventHandler('onResourceStart', function(resource)
    if resource == 'lb-phone' then
        Wait(1000)
        addApp()
    end
end)

------------------------------------------------------------------------
-- NUI <-> server bridge
-- Each UI fetchNui('name', data) resolves with the server callback result.
------------------------------------------------------------------------
local function bridge(nuiName, serverCallback)
    RegisterNUICallback(nuiName, function(data, cb)
        QBCore.Functions.TriggerCallback(serverCallback, function(result)
            cb(result)
        end, data)
    end)
end

bridge('getMeta',        'wheeldeal:server:getMeta')
bridge('getMyVehicles',  'wheeldeal:server:getMyVehicles')
bridge('getListings',    'wheeldeal:server:getListings')
bridge('getListing',     'wheeldeal:server:getListing')
bridge('createListing',  'wheeldeal:server:createListing')
bridge('editListing',    'wheeldeal:server:editListing')
bridge('removeListing',  'wheeldeal:server:removeListing')
bridge('addImages',      'wheeldeal:server:addImages')
bridge('toggleFavorite', 'wheeldeal:server:toggleFavorite')
bridge('getFavorites',   'wheeldeal:server:getFavorites')
bridge('getDashboard',   'wheeldeal:server:getDashboard')
bridge('relist',         'wheeldeal:server:relist')
bridge('purchase',       'wheeldeal:server:purchase')
bridge('submitOffer',    'wheeldeal:server:submitOffer')
bridge('offerAction',    'wheeldeal:server:offerAction')
bridge('acceptCounter',  'wheeldeal:server:acceptCounter')
bridge('withdrawOffer',  'wheeldeal:server:withdrawOffer')
bridge('reportListing',  'wheeldeal:server:reportListing')
bridge('messageSeller',  'wheeldeal:server:messageSeller')

------------------------------------------------------------------------
-- Call Seller (client-side; opens the phone's call UI)
------------------------------------------------------------------------
RegisterNUICallback('callSeller', function(data, cb)
    if data and data.number and data.number ~= '' then
        pcall(function()
            exports['lb-phone']:CreateCall({ number = data.number })
        end)
        cb({ success = true })
    else
        cb({ success = false })
    end
end)
