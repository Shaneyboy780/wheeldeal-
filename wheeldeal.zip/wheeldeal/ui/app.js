/* =====================================================================
   AutoTrader LS - app.js
   Single-page app for the LB-Phone custom app. Loaded only after
   'componentsLoaded', so fetchNui / selectGallery / getSettings exist.
   ===================================================================== */
(function () {
    'use strict';

    // ---- element refs ----
    const appEl    = document.getElementById('app');
    const rootEl   = document.getElementById('root');
    const modalRoot= document.getElementById('modal-root');
    const toastRoot= document.getElementById('toast-root');

    // ---- state ----
    const state = {
        meta: null,
        view: 'browse',
        list: { search: '', seller: '', category: 'all', sort: 'newest', page: 1, items: [], hasMore: false, loading: false },
        dashTab: 'active',
        sell: { mode: 'create', listingId: null, vehicle: null, photos: [], category: null, condition: 5 },
        searchMode: 'name', // 'name' | 'seller'
    };

    // ---- tiny helpers ----
    const esc = (s) => String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

    const cur = () => (state.meta && state.meta.currency) || '$';
    const money = (n) => cur() + Number(n || 0).toLocaleString('en-US');

    function timeAgo(ts) {
        if (ts == null || ts === '') return '';
        let d;
        if (typeof ts === 'number') {
            d = new Date(ts < 1e12 ? ts * 1000 : ts);   // epoch seconds vs ms
        } else if (ts instanceof Date) {
            d = ts;
        } else {
            d = new Date(String(ts).replace(' ', 'T'));  // "YYYY-MM-DD HH:MM:SS"
            if (isNaN(d)) d = new Date(String(ts));      // fall back to raw/ISO
        }
        if (isNaN(d)) return '';
        const diff = (Date.now() - d.getTime()) / 1000;
        if (diff < 0) return 'Just now';
        if (diff < 60) return 'Just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
        return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }

    const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

    function starsHtml(rating, size) {
        let h = '<span class="stars" style="font-size:' + (size || 0.85) + 'rem">';
        for (let i = 1; i <= 5; i++) h += '<i class="fa-' + (i <= rating ? 'solid' : 'regular') + ' fa-star' + (i > rating ? ' off' : '') + '"></i>';
        return h + '</span>';
    }

    // ---- API bridge ----
    function api(name, data) {
        if (typeof window.fetchNui !== 'function') return Promise.resolve(null);
        return window.fetchNui(name, data || {}).catch(() => null);
    }

    // ---- toast ----
    let toastTimer;
    function toast(msg, type) {
        const t = document.createElement('div');
        t.className = 'toast ' + (type === 'err' ? 'err' : 'ok');
        t.innerHTML = '<i class="fa-solid fa-' + (type === 'err' ? 'circle-exclamation' : 'circle-check') + '"></i>' + esc(msg);
        toastRoot.innerHTML = '';
        toastRoot.appendChild(t);
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => { t.style.opacity = '0'; setTimeout(() => toastRoot.innerHTML = '', 200); }, 2600);
    }

    // ---- modal ----
    function closeModal() { modalRoot.innerHTML = ''; }
    function modal(opts) {
        // opts: { icon, danger, title, desc, input(type/placeholder/value), confirmLabel, cancelLabel, onConfirm }
        const hasInput = !!opts.input;
        const iconCls = opts.danger ? 'danger' : 'accent';
        modalRoot.innerHTML =
            '<div class="modal-backdrop" id="mb">' +
              '<div class="modal">' +
                (opts.icon ? '<div class="modal-icon ' + iconCls + '"><i class="fa-solid fa-' + opts.icon + '"></i></div>' : '') +
                '<div class="modal-title">' + esc(opts.title) + '</div>' +
                (opts.desc ? '<div class="modal-desc">' + esc(opts.desc) + '</div>' : '') +
                (hasInput ?
                    '<div class="modal-input"><input class="input" id="mInput" type="' + (opts.input.type || 'text') +
                    '" inputmode="' + (opts.input.type === 'number' ? 'numeric' : 'text') + '" placeholder="' +
                    esc(opts.input.placeholder || '') + '" value="' + esc(opts.input.value || '') + '" /></div>' : '') +
                '<div class="modal-actions">' +
                  '<button class="btn btn-secondary" id="mCancel">' + esc(opts.cancelLabel || 'Cancel') + '</button>' +
                  '<button class="btn ' + (opts.danger ? 'btn-danger' : 'btn-primary') + '" id="mOk">' + esc(opts.confirmLabel || 'Confirm') + '</button>' +
                '</div>' +
              '</div>' +
            '</div>';
        const inputEl = document.getElementById('mInput');
        if (inputEl) setTimeout(() => inputEl.focus(), 60);
        document.getElementById('mCancel').onclick = closeModal;
        document.getElementById('mb').onclick = (e) => { if (e.target.id === 'mb') closeModal(); };
        document.getElementById('mOk').onclick = () => {
            const val = inputEl ? inputEl.value : null;
            opts.onConfirm && opts.onConfirm(val);
        };
    }

    // ---- theme ----
    function applyTheme(theme) { appEl.dataset.theme = (theme === 'light') ? 'light' : 'dark'; }
    if (typeof window.getSettings === 'function') {
        window.getSettings().then((s) => applyTheme(s && s.display && s.display.theme)).catch(() => {});
    }
    if (typeof window.onSettingsChange === 'function') {
        window.onSettingsChange((s) => applyTheme(s && s.display && s.display.theme));
    }

    // =================================================================
    // ROUTER
    // =================================================================
    function setView(view) { state.view = view; render(); }

    function tabbar() {
        const items = [
            ['browse', 'car', 'Browse'],
            ['favorites', 'heart', 'Saved'],
            ['sell', 'circle-plus', 'Sell'],
            ['dashboard', 'gauge-high', 'Garage'],
        ];
        return '<div class="tabbar">' + items.map(([v, i, l]) =>
            '<div class="tabbar-item' + (state.view === v ? ' active' : '') + '" data-nav="' + v + '">' +
            '<i class="fa-solid fa-' + i + '"></i><span>' + l + '</span></div>').join('') + '</div>';
    }

    function bindTabbar() {
        rootEl.querySelectorAll('[data-nav]').forEach((n) => n.onclick = () => {
            const v = n.dataset.nav;
            if (v === 'sell') { state.sell = { mode: 'create', listingId: null, vehicle: null, photos: [], category: null, condition: 5 }; }
            setView(v);
        });
    }

    function render() {
        if (state.view === 'browse') return renderBrowse();
        if (state.view === 'favorites') return renderFavorites();
        if (state.view === 'sell') return renderSell();
        if (state.view === 'dashboard') return renderDashboard();
        if (state.view === 'detail') return; // handled by openDetail
    }

    // =================================================================
    // BROWSE / MARKETPLACE
    // =================================================================
    function renderBrowse() {
        const sorts = [
            ['newest', 'Newest'], ['oldest', 'Oldest'],
            ['price_asc', 'Price: Low to High'], ['price_desc', 'Price: High to Low'],
            ['mileage_asc', 'Mileage: Low to High'], ['mileage_desc', 'Mileage: High to Low'],
        ];
        const cats = [['all', 'All']].concat((state.meta.categories || []).map((c) => [c.key, c.label]));

        rootEl.innerHTML =
            '<div class="screen view-enter">' +
              '<div class="topbar"><div class="topbar-title">AutoTrader<span style="color:var(--accent)"> LS</span></div>' +
                '<div class="topbar-action" id="searchToggle" title="Search mode"><i class="fa-solid fa-' + (state.searchMode === 'name' ? 'car' : 'user') + '"></i></div>' +
              '</div>' +
              '<div class="scroll">' +
                '<div class="search-row"><i class="fa-solid fa-magnifying-glass"></i>' +
                  '<input class="search-input" id="search" placeholder="' + (state.searchMode === 'name' ? 'Search vehicles…' : 'Search by seller…') + '" value="' + esc(state.searchMode === 'name' ? state.list.search : state.list.seller) + '" /></div>' +
                '<div class="controls-row"><select class="sort-select" id="sort">' +
                  sorts.map(([v, l]) => '<option value="' + v + '"' + (state.list.sort === v ? ' selected' : '') + '>' + l + '</option>').join('') +
                '</select></div>' +
                '<div class="chips" id="chips">' +
                  cats.map(([k, l]) => '<div class="chip' + (state.list.category === k ? ' active' : '') + '" data-cat="' + k + '">' + esc(l) + '</div>').join('') +
                '</div>' +
                '<div id="results"></div>' +
              '</div>' +
              tabbar() +
            '</div>';

        bindTabbar();

        document.getElementById('searchToggle').onclick = () => {
            state.searchMode = state.searchMode === 'name' ? 'seller' : 'name';
            renderBrowse();
        };
        const searchEl = document.getElementById('search');
        searchEl.oninput = debounce(() => {
            if (state.searchMode === 'name') state.list.search = searchEl.value;
            else state.list.seller = searchEl.value;
            loadListings(true);
        }, 350);
        document.getElementById('sort').onchange = (e) => { state.list.sort = e.target.value; loadListings(true); };
        document.getElementById('chips').querySelectorAll('[data-cat]').forEach((c) => c.onclick = () => {
            state.list.category = c.dataset.cat; renderBrowse();
        });

        loadListings(true);
    }

    function cardHtml(l) {
        const cover = l.cover
            ? '<img src="' + esc(l.cover) + '" loading="lazy" />'
            : '<div class="ph"><i class="fa-solid fa-car-side"></i></div>';
        const badge = (l.status && l.status !== 'active')
            ? '<div class="badge ' + esc(l.status) + '">' + esc(l.status) + '</div>' : '';
        return '<div class="card" data-id="' + l.id + '">' +
            '<div class="card-img">' + cover + badge + '</div>' +
            '<div class="card-body">' +
              '<div class="card-title">' + esc(l.title) + '</div>' +
              '<div class="card-meta"><i class="fa-solid fa-gauge"></i> ' + Number(l.mileage || 0).toLocaleString('en-US') + ' mi</div>' +
              '<div class="card-price">' + money(l.price) + '</div>' +
              '<div class="card-seller"><i class="fa-regular fa-user"></i> ' + esc(l.seller_name) + '</div>' +
            '</div></div>';
    }

    async function loadListings(reset) {
        const results = document.getElementById('results');
        if (!results) return;
        if (reset) { state.list.page = 1; state.list.items = []; results.innerHTML = '<div class="loading"><div class="spinner"></div></div>'; }
        state.list.loading = true;

        const res = await api('getListings', {
            search: state.searchMode === 'name' ? state.list.search : '',
            seller: state.searchMode === 'seller' ? state.list.seller : '',
            category: state.list.category, sort: state.list.sort, page: state.list.page,
        });
        state.list.loading = false;
        const data = res || { listings: [], hasMore: false };
        state.list.items = state.list.items.concat(data.listings || []);
        state.list.hasMore = !!data.hasMore;

        if (state.list.items.length === 0) {
            results.innerHTML = '<div class="empty"><i class="fa-solid fa-car-side"></i><h3>No listings found</h3><p>Try a different search or category, or be the first to list a vehicle.</p></div>';
            return;
        }
        results.innerHTML = '<div class="grid">' + state.list.items.map(cardHtml).join('') +
            '</div>' + (state.list.hasMore ? '<button class="load-more" id="more">Load more</button>' : '');
        results.querySelectorAll('.card').forEach((c) => c.onclick = () => openDetail(Number(c.dataset.id)));
        const more = document.getElementById('more');
        if (more) more.onclick = () => { state.list.page++; loadListings(false); };
    }

    // =================================================================
    // DETAIL
    // =================================================================
    async function openDetail(id) {
        state.view = 'detail';
        rootEl.innerHTML = '<div class="screen"><div class="loading"><div class="spinner"></div></div></div>';
        const l = await api('getListing', { id });
        if (!l) { toast('Listing unavailable', 'err'); return backToBrowse(); }

      try {
        const imgs = (l.images && l.images.length)
            ? l.images.map((u) => '<div class="slide"><img src="' + esc(u) + '" /></div>').join('')
            : '<div class="slide"><div class="ph"><i class="fa-solid fa-car-side"></i></div></div>';
        const dots = (l.images && l.images.length > 1)
            ? '<div class="carousel-dots">' + l.images.map((_, i) => '<div class="dot' + (i === 0 ? ' active' : '') + '"></div>').join('') + '</div>' : '';
        const count = (l.images && l.images.length > 1) ? '<div class="carousel-count"><span id="cIdx">1</span>/' + l.images.length + '</div>' : '';

        const catLabel = (state.meta.categories.find((c) => c.key === l.category) || {}).label || l.category;

        let actions = '';
        if (l.isOwner) {
            actions = '<div class="owner-note"><i class="fa-solid fa-circle-info"></i> This is your listing. Manage it from your Garage.</div>' +
                '<div class="action-stack"><button class="btn btn-secondary btn-block" id="goManage"><i class="fa-solid fa-gauge-high"></i> Manage Listing</button></div>';
        } else if (l.status !== 'active') {
            actions = '<div class="owner-note">This listing is ' + esc(l.status) + ' and no longer available.</div>';
        } else {
            let counterBlock = '';
            if (l.myOffer && l.myOffer.status === 'countered' && l.myOffer.counter_amount) {
                counterBlock = '<div class="contact-box" style="background:var(--positive-soft)"><span class="lbl" style="color:var(--positive)">Seller counter offer</span>' +
                    'The seller countered at <b>' + money(l.myOffer.counter_amount) + '</b></div>' +
                    '<button class="btn btn-block" style="background:var(--positive);color:#fff;margin-top:0.55rem" id="acceptCounter">Accept counter (' + money(l.myOffer.counter_amount) + ')</button>';
            } else if (l.myOffer && l.myOffer.status === 'pending') {
                counterBlock = '<div class="contact-box"><span class="lbl">Your offer</span>You have a pending offer of <b>' + money(l.myOffer.amount) + '</b></div>';
            }
            actions =
                '<div class="action-stack">' +
                  '<button class="btn btn-primary btn-block" id="buyNow"><i class="fa-solid fa-bolt"></i> Buy Now · ' + money(l.price) + '</button>' +
                  '<button class="btn btn-ghost btn-block" id="makeOffer"><i class="fa-solid fa-hand-holding-dollar"></i> ' + (l.myOffer ? 'Update Offer' : 'Make an Offer') + '</button>' +
                  counterBlock +
                '</div>' +
                '<div class="icon-actions">' +
                  '<button class="icon-btn" id="msg"><i class="fa-solid fa-comment"></i>Message</button>' +
                  '<button class="icon-btn" id="call"><i class="fa-solid fa-phone"></i>Call</button>' +
                  '<button class="icon-btn ' + (l.isFavorite ? 'on' : '') + '" id="fav"><i class="fa-' + (l.isFavorite ? 'solid' : 'regular') + ' fa-heart"></i>Save</button>' +
                  '<button class="icon-btn" id="report"><i class="fa-solid fa-flag"></i>Report</button>' +
                '</div>';
        }

        rootEl.innerHTML =
            '<div class="screen view-enter">' +
              '<div class="topbar"><div class="back-btn" id="back"><i class="fa-solid fa-chevron-left"></i></div>' +
                '<div class="topbar-title" style="font-size:1.05rem">Vehicle Details</div></div>' +
              '<div class="scroll flush">' +
                '<div class="carousel"><div class="carousel-track" id="track">' + imgs + '</div>' + count + dots + '</div>' +
                '<div style="padding:0 1.1rem 1.2rem">' +
                  '<div class="detail-head"><div style="flex:1"><div class="detail-title">' + esc(l.title) + '</div>' +
                    (l.brand ? '<div class="detail-brand">' + esc(l.brand) + ' · ' + esc(l.modelLabel) + '</div>' : '') +
                  '</div><div class="detail-price">' + money(l.price) + '</div></div>' +
                  '<div class="specs">' +
                    specRow('road', 'Plate', esc(l.plate)) +
                    specRow('gauge', 'Mileage', Number(l.mileage).toLocaleString('en-US') + ' mi') +
                    specRow('star', 'Condition', starsHtml(l.condition)) +
                    specRow('tag', 'Category', esc(catLabel)) +
                    specRow('calendar', 'Listed', timeAgo(l.createdAt)) +
                  '</div>' +
                  (l.description ? '<div class="section-title">Description</div><div class="desc-text">' + esc(l.description) + '</div>' : '') +
                  (l.contact ? '<div class="contact-box"><span class="lbl">Contact notes</span>' + esc(l.contact) + '</div>' : '') +
                  '<div class="seller-row"><div class="avatar">' + esc((l.sellerName || '?').charAt(0).toUpperCase()) + '</div>' +
                    '<div style="flex:1"><div class="seller-name">' + esc(l.sellerName) + '</div><div class="seller-meta">Seller</div></div></div>' +
                  actions +
                '</div>' +
              '</div>' +
            '</div>';

        document.getElementById('back').onclick = backToBrowse;

        // carousel dots
        const track = document.getElementById('track');
        if (track && l.images && l.images.length > 1) {
            track.onscroll = () => {
                const idx = Math.round(track.scrollLeft / track.clientWidth);
                const cIdx = document.getElementById('cIdx'); if (cIdx) cIdx.textContent = idx + 1;
                rootEl.querySelectorAll('.dot').forEach((d, i) => d.classList.toggle('active', i === idx));
            };
        }

        // owner / status
        const gm = document.getElementById('goManage'); if (gm) gm.onclick = () => { state.dashTab = 'active'; setView('dashboard'); };

        // buyer actions
        const buy = document.getElementById('buyNow');
        if (buy) buy.onclick = () => modal({
            icon: 'bolt', title: 'Confirm Purchase',
            desc: 'Buy ' + l.title + ' for ' + money(l.price) + '? This will transfer the vehicle to you and pay the seller.',
            confirmLabel: 'Buy Now',
            onConfirm: async () => {
                closeModal();
                const r = await api('purchase', { id: l.id });
                if (r && r.success) { toast('Purchase complete!'); backToBrowse(); }
                else toast((r && r.message) || 'Purchase failed', 'err');
            }
        });

        const off = document.getElementById('makeOffer');
        if (off) off.onclick = () => modal({
            icon: 'hand-holding-dollar', title: l.myOffer ? 'Update Offer' : 'Make an Offer',
            desc: 'Listed at ' + money(l.price) + '. Enter your offer amount.',
            input: { type: 'number', placeholder: 'Offer amount', value: l.myOffer ? l.myOffer.amount : '' },
            confirmLabel: 'Send Offer',
            onConfirm: async (val) => {
                const amt = parseInt(val, 10);
                if (!amt || amt <= 0) return toast('Enter a valid amount', 'err');
                closeModal();
                const r = await api('submitOffer', { id: l.id, amount: amt });
                if (r && r.success) { toast('Offer sent to seller'); openDetail(l.id); }
                else toast((r && r.message) || 'Could not send offer', 'err');
            }
        });

        const ac = document.getElementById('acceptCounter');
        if (ac) ac.onclick = () => modal({
            icon: 'handshake', title: 'Accept Counter',
            desc: 'Buy ' + l.title + ' for ' + money(l.myOffer.counter_amount) + '?',
            confirmLabel: 'Accept & Buy',
            onConfirm: async () => {
                closeModal();
                const r = await api('acceptCounter', { offerId: l.myOffer.id });
                if (r && r.success) { toast('Purchase complete!'); backToBrowse(); }
                else toast((r && r.message) || 'Could not complete', 'err');
            }
        });

        const msg = document.getElementById('msg');
        if (msg) msg.onclick = async () => {
            const r = await api('messageSeller', { id: l.id });
            toast((r && r.message) || (r && r.success ? 'Message sent' : 'Could not message seller'), (r && r.success) ? 'ok' : 'err');
        };

        const call = document.getElementById('call');
        if (call) call.onclick = async () => {
            if (!l.sellerNumber) return toast('Seller phone unavailable', 'err');
            await api('callSeller', { number: l.sellerNumber });
        };

        const fav = document.getElementById('fav');
        if (fav) fav.onclick = async () => {
            const r = await api('toggleFavorite', { id: l.id });
            if (r && r.success) {
                fav.classList.toggle('on', r.favorited);
                fav.querySelector('i').className = (r.favorited ? 'fa-solid' : 'fa-regular') + ' fa-heart';
                toast(r.favorited ? 'Saved to favorites' : 'Removed from favorites');
            }
        };

        const rep = document.getElementById('report');
        if (rep) rep.onclick = () => modal({
            icon: 'flag', danger: true, title: 'Report Listing',
            desc: 'Tell the admins what is wrong with this listing.',
            input: { type: 'text', placeholder: 'Reason' },
            confirmLabel: 'Submit Report',
            onConfirm: async (val) => {
                closeModal();
                const r = await api('reportListing', { id: l.id, reason: val });
                toast(r && r.success ? 'Report submitted' : 'Could not submit', r && r.success ? 'ok' : 'err');
            }
        });
      } catch (err) {
        rootEl.innerHTML =
            '<div class="screen view-enter">' +
              '<div class="topbar"><div class="back-btn" id="back"><i class="fa-solid fa-chevron-left"></i></div>' +
                '<div class="topbar-title" style="font-size:1.05rem">Vehicle Details</div></div>' +
              '<div class="scroll"><div class="empty"><i class="fa-solid fa-triangle-exclamation"></i>' +
                '<h3>Could not display this listing</h3><p>Please go back and try again.</p></div></div>' +
            '</div>';
        const b = document.getElementById('back'); if (b) b.onclick = backToBrowse;
      }
    }

    function specRow(icon, label, value) {
        return '<div class="spec-row"><div class="spec-label"><i class="fa-solid fa-' + icon + '"></i>' + label + '</div>' +
            '<div class="spec-value">' + value + '</div></div>';
    }

    function backToBrowse() { setView('browse'); }

    // =================================================================
    // SELL / EDIT
    // =================================================================
    async function renderSell(prefill) {
        const isEdit = state.sell.mode === 'edit';
        rootEl.innerHTML = '<div class="screen"><div class="loading"><div class="spinner"></div></div></div>';

        let vehicles = [];
        if (!isEdit) vehicles = (await api('getMyVehicles')) || [];

        const cats = state.meta.categories || [];
        const s = state.sell;

        rootEl.innerHTML =
            '<div class="screen view-enter">' +
              '<div class="topbar">' + (isEdit ? '<div class="back-btn" id="back"><i class="fa-solid fa-chevron-left"></i></div>' : '') +
                '<div class="topbar-title">' + (isEdit ? 'Edit Listing' : 'Sell a Vehicle') + '</div></div>' +
              '<div class="scroll">' +
                (isEdit ? '' :
                  '<div class="field"><label class="field-label">Vehicle <span class="req">*</span></label>' +
                  '<div class="veh-select"><button class="veh-trigger placeholder" id="vehTrigger"><span id="vehLabel">Select a vehicle you own</span><i class="fa-solid fa-chevron-down"></i></button>' +
                  '<div class="veh-menu" id="vehMenu" style="display:none"></div></div></div>') +

                '<div class="field"><label class="field-label">Photos</label>' +
                  '<div class="photos" id="photos"></div>' +
                  (isEdit ? '<div class="char-count">First photo is the cover. New photos are added to this listing.</div>'
                          : '<div class="char-count">First photo becomes the cover image.</div>') +
                '</div>' +

                '<div class="field"><label class="field-label">Title <span class="req">*</span></label>' +
                  '<input class="input" id="title" maxlength="' + 60 + '" placeholder="e.g. Clean Sultan RS, low miles" /></div>' +

                '<div class="field"><label class="field-label">Price <span class="req">*</span></label>' +
                  '<div class="price-input"><span class="cur">' + cur() + '</span><input class="input" id="price" type="number" inputmode="numeric" placeholder="0" /></div></div>' +

                '<div class="field"><label class="field-label">Mileage (mi)</label>' +
                  '<input class="input" id="mileage" type="number" inputmode="numeric" placeholder="0" /></div>' +

                '<div class="field"><label class="field-label">Condition</label><div class="star-picker" id="stars"></div></div>' +

                '<div class="field"><label class="field-label">Category</label><div class="chips" id="catChips">' +
                  cats.map((c) => '<div class="chip" data-cat="' + c.key + '">' + esc(c.label) + '</div>').join('') +
                '</div></div>' +

                '<div class="field"><label class="field-label">Description</label>' +
                  '<textarea class="textarea" id="desc" maxlength="600" placeholder="Mods, history, condition details…"></textarea>' +
                  '<div class="char-count"><span id="descCount">0</span>/600</div></div>' +

                '<div class="field"><label class="field-label">Contact notes</label>' +
                  '<input class="input" id="contact" maxlength="160" placeholder="Best way to reach you, availability…" /></div>' +

                '<div class="submit-bar"><button class="btn btn-primary btn-block" id="submit">' +
                  (isEdit ? 'Save Changes' : 'Post Listing') + '</button></div>' +
              '</div>' +
              (isEdit ? '' : tabbar()) +
            '</div>';

        if (!isEdit) bindTabbar();
        const back = document.getElementById('back'); if (back) back.onclick = () => { state.dashTab = 'active'; setView('dashboard'); };

        // ----- vehicle dropdown -----
        if (!isEdit) {
            const trigger = document.getElementById('vehTrigger');
            const menu = document.getElementById('vehMenu');
            if (!vehicles.length) {
                menu.innerHTML = '<div class="veh-option disabled"><div class="v-name">No vehicles owned</div><div class="v-sub">Buy or own a vehicle to list it</div></div>';
            } else {
                menu.innerHTML = vehicles.map((v, i) => {
                    const tags = [];
                    if (v.alreadyListed) tags.push('Already listed');
                    if (v.financed) tags.push('Finance owing');
                    return '<div class="veh-option' + (v.alreadyListed ? ' disabled' : '') + '" data-i="' + i + '">' +
                        '<div class="v-name">' + esc(v.label) + (v.brand ? ' · ' + esc(v.brand) : '') + '</div>' +
                        '<div class="v-sub">' + esc(v.plate) + (tags.length ? ' · ' + tags.join(' · ') : '') + '</div></div>';
                }).join('');
            }
            trigger.onclick = () => { menu.style.display = menu.style.display === 'none' ? 'block' : 'none'; };
            menu.querySelectorAll('.veh-option[data-i]').forEach((o) => o.onclick = () => {
                const v = vehicles[Number(o.dataset.i)];
                state.sell.vehicle = v;
                document.getElementById('vehLabel').textContent = v.label + ' (' + v.plate + ')';
                trigger.classList.remove('placeholder');
                menu.style.display = 'none';
                // prefill helpers
                const titleEl = document.getElementById('title');
                if (!titleEl.value) titleEl.value = v.label;
                if (v.suggestedCat) selectCat(v.suggestedCat);
            });
        }

        // ----- photos -----
        renderPhotos();

        // ----- stars -----
        renderStars();

        // ----- category chips -----
        document.getElementById('catChips').querySelectorAll('[data-cat]').forEach((c) => c.onclick = () => selectCat(c.dataset.cat));

        // ----- char count -----
        const desc = document.getElementById('desc');
        desc.oninput = () => { document.getElementById('descCount').textContent = desc.value.length; };

        // ----- prefill (edit) -----
        if (isEdit && prefill) {
            document.getElementById('title').value = prefill.title || '';
            document.getElementById('price').value = prefill.price || '';
            document.getElementById('mileage').value = prefill.mileage || '';
            document.getElementById('contact').value = prefill.contact || '';
            desc.value = prefill.description || '';
            document.getElementById('descCount').textContent = desc.value.length;
            state.sell.condition = prefill.condition || 5;
            renderStars();
            if (prefill.category) selectCat(prefill.category);
        }

        document.getElementById('submit').onclick = submitSell;
    }

    function selectCat(key) {
        state.sell.category = key;
        rootEl.querySelectorAll('#catChips [data-cat]').forEach((c) => c.classList.toggle('active', c.dataset.cat === key));
    }

    function renderStars() {
        const wrap = document.getElementById('stars'); if (!wrap) return;
        wrap.innerHTML = '';
        for (let i = 1; i <= 5; i++) {
            const st = document.createElement('i');
            st.className = 'fa-solid fa-star star' + (i <= state.sell.condition ? ' on' : '');
            st.onclick = () => { state.sell.condition = i; renderStars(); };
            wrap.appendChild(st);
        }
    }

    function renderPhotos() {
        const wrap = document.getElementById('photos'); if (!wrap) return;
        const max = (state.meta && state.meta.maxImages) || 8;
        let html = state.sell.photos.map((url, i) =>
            '<div class="photo-thumb"><img src="' + esc(url) + '" /><div class="rm" data-rm="' + i + '"><i class="fa-solid fa-xmark"></i></div>' +
            (i === 0 ? '<div class="cover-tag">Cover</div>' : '') + '</div>').join('');
        if (state.sell.photos.length < max) {
            html += '<button class="photo-add" id="addPhoto"><i class="fa-solid fa-camera"></i>Add</button>';
        }
        wrap.innerHTML = html;
        wrap.querySelectorAll('[data-rm]').forEach((b) => b.onclick = () => {
            state.sell.photos.splice(Number(b.dataset.rm), 1); renderPhotos();
        });
        const add = document.getElementById('addPhoto');
        if (add) add.onclick = pickPhotos;
    }

    function pickPhotos() {
        const max = (state.meta && state.meta.maxImages) || 8;
        const handler = (data) => {
            if (!data) return;
            const arr = Array.isArray(data) ? data : [data];
            arr.forEach((item) => {
                const url = typeof item === 'string' ? item : (item && (item.src || item.url));
                if (url && state.sell.photos.length < max && state.sell.photos.indexOf(url) === -1) {
                    state.sell.photos.push(url);
                }
            });
            // edit mode: push straight to the listing
            if (state.sell.mode === 'edit' && state.sell.listingId) {
                api('addImages', { id: state.sell.listingId, urls: arr.map((it) => typeof it === 'string' ? it : (it && (it.src || it.url))).filter(Boolean) })
                    .then((r) => { if (r && r.success) toast('Photos added'); });
            }
            renderPhotos();
        };
        if (typeof window.selectGallery === 'function') {
            window.selectGallery({ includeImages: true, includeVideos: false, multiSelect: true, allowExternal: true, cb: handler, onSelect: handler });
        } else {
            toast('Gallery unavailable', 'err');
        }
    }

    async function submitSell() {
        const s = state.sell;
        const title = document.getElementById('title').value.trim();
        const price = parseInt(document.getElementById('price').value, 10);
        const mileage = parseInt(document.getElementById('mileage').value, 10) || 0;
        const description = document.getElementById('desc').value;
        const contactNotes = document.getElementById('contact').value;

        if (s.mode === 'create' && !s.vehicle) return toast('Select a vehicle', 'err');
        if (!title) return toast('Enter a title', 'err');
        if (!price || price <= 0) return toast('Enter a valid price', 'err');

        const btn = document.getElementById('submit'); btn.disabled = true; btn.textContent = 'Working…';

        if (s.mode === 'edit') {
            const r = await api('editListing', {
                id: s.listingId, title, price, mileage, condition: s.condition,
                category: s.category || 'cars', description, contactNotes,
            });
            btn.disabled = false; btn.textContent = 'Save Changes';
            if (r && r.success) { toast('Listing updated'); state.dashTab = 'active'; setView('dashboard'); }
            else toast((r && r.message) || 'Could not save', 'err');
        } else {
            const r = await api('createListing', {
                plate: s.vehicle.plate, title, price, mileage, condition: s.condition,
                category: s.category || s.vehicle.suggestedCat || 'cars',
                description, contactNotes, images: s.photos,
            });
            btn.disabled = false; btn.textContent = 'Post Listing';
            if (r && r.success) { toast('Listing posted!'); state.dashTab = 'active'; setView('dashboard'); }
            else toast((r && r.message) || 'Could not create listing', 'err');
        }
    }

    // =================================================================
    // FAVORITES
    // =================================================================
    async function renderFavorites() {
        rootEl.innerHTML = '<div class="screen view-enter"><div class="topbar"><div class="topbar-title">Saved</div></div>' +
            '<div class="scroll"><div class="loading"><div class="spinner"></div></div></div>' + tabbar() + '</div>';
        bindTabbar();
        const items = (await api('getFavorites')) || [];
        const scroll = rootEl.querySelector('.scroll');
        if (!items.length) {
            scroll.innerHTML = '<div class="empty"><i class="fa-regular fa-heart"></i><h3>No saved listings</h3><p>Tap the heart on any listing to save it here.</p></div>';
            return;
        }
        scroll.innerHTML = items.map((l) => {
            const thumb = l.cover ? '<img src="' + esc(l.cover) + '" />' : '<div class="ph"><i class="fa-solid fa-car-side"></i></div>';
            const status = l.status !== 'active' ? '<span class="status-tag ' + esc(l.status) + '">' + esc(l.status) + '</span> ' : '';
            return '<div class="list-card" data-id="' + l.id + '"><div class="list-thumb">' + thumb + '</div>' +
                '<div class="list-info"><div class="list-title">' + esc(l.title) + '</div>' +
                  '<div class="list-sub">' + status + esc(l.seller_name) + ' · ' + Number(l.mileage || 0).toLocaleString('en-US') + ' mi</div>' +
                  '<div class="list-price">' + money(l.price) + '</div>' +
                  '<div class="list-actions"><button class="mini-btn danger" data-unfav="' + l.id + '"><i class="fa-solid fa-heart-crack"></i> Remove</button></div>' +
                '</div></div>';
        }).join('');
        scroll.querySelectorAll('.list-card').forEach((c) => c.onclick = (e) => {
            if (e.target.closest('[data-unfav]')) return;
            openDetail(Number(c.dataset.id));
        });
        scroll.querySelectorAll('[data-unfav]').forEach((b) => b.onclick = async (e) => {
            e.stopPropagation();
            const r = await api('toggleFavorite', { id: Number(b.dataset.unfav) });
            if (r && r.success) { toast('Removed from favorites'); renderFavorites(); }
        });
    }

    // =================================================================
    // DASHBOARD (seller garage)
    // =================================================================
    async function renderDashboard() {
        rootEl.innerHTML = '<div class="screen view-enter"><div class="topbar"><div class="topbar-title">Your Garage</div></div>' +
            '<div class="scroll"><div class="loading"><div class="spinner"></div></div></div>' + tabbar() + '</div>';
        bindTabbar();
        const data = (await api('getDashboard')) || { active: [], sold: [], expired: [], offers: [] };
        const scroll = rootEl.querySelector('.scroll');

        const tabs = [
            ['active', 'Active', data.active.length],
            ['offers', 'Offers', data.offers.length],
            ['sold', 'Sold', data.sold.length],
            ['expired', 'Expired', data.expired.length],
        ];
        const tabsHtml = '<div class="tabs">' + tabs.map(([k, l, n]) =>
            '<div class="tab' + (state.dashTab === k ? ' active' : '') + '" data-tab="' + k + '">' + l + (n ? ' (' + n + ')' : '') + '</div>').join('') + '</div>';

        let body = '';
        if (state.dashTab === 'active') body = activeList(data.active);
        else if (state.dashTab === 'offers') body = offersList(data.offers);
        else if (state.dashTab === 'sold') body = soldList(data.sold);
        else if (state.dashTab === 'expired') body = expiredList(data.expired);

        scroll.innerHTML = tabsHtml + '<div id="dashBody">' + body + '</div>';
        scroll.querySelectorAll('[data-tab]').forEach((t) => t.onclick = () => { state.dashTab = t.dataset.tab; renderDashboard(); });
        bindDashboardActions(data);
    }

    function thumbOf(l) {
        return l.cover ? '<img src="' + esc(l.cover) + '" />' : '<div class="ph"><i class="fa-solid fa-car-side"></i></div>';
    }

    function activeList(items) {
        if (!items.length) return emptyBlock('car-side', 'No active listings', 'List a vehicle from the Sell tab.');
        return items.map((l) =>
            '<div class="list-card"><div class="list-thumb">' + thumbOf(l) + '</div>' +
            '<div class="list-info"><div class="list-title">' + esc(l.title) + '</div>' +
              '<div class="list-sub">' + Number(l.mileage || 0).toLocaleString('en-US') + ' mi' +
                (l.offerCount > 0 ? ' · <span class="pill"><i class="fa-solid fa-hand-holding-dollar"></i> ' + l.offerCount + ' offer' + (l.offerCount > 1 ? 's' : '') + '</span>' : '') + '</div>' +
              '<div class="list-price">' + money(l.price) + '</div>' +
              '<div class="list-actions">' +
                '<button class="mini-btn" data-edit="' + l.id + '"><i class="fa-solid fa-pen"></i> Edit</button>' +
                '<button class="mini-btn" data-price="' + l.id + '"><i class="fa-solid fa-dollar-sign"></i> Price</button>' +
                '<button class="mini-btn" data-photos="' + l.id + '"><i class="fa-solid fa-camera"></i> Photos</button>' +
                '<button class="mini-btn danger" data-remove="' + l.id + '"><i class="fa-solid fa-trash"></i> Remove</button>' +
              '</div></div></div>').join('');
    }

    function offersList(items) {
        if (!items.length) return emptyBlock('hand-holding-dollar', 'No pending offers', 'Offers on your listings will appear here.');
        return items.map((o) => {
            const countered = o.status === 'countered';
            return '<div class="offer-card"><div class="offer-top"><div><div class="offer-buyer">' + esc(o.buyer_name) + '</div>' +
                '<div class="offer-on">on ' + esc(o.title) + '</div></div>' +
                '<div style="text-align:right"><div class="offer-amount">' + money(o.amount) + '</div>' +
                (countered ? '<div class="offer-counter">You countered: ' + money(o.counter_amount) + '</div>' : '') + '</div></div>' +
                (countered ? '<div class="offer-counter"><i class="fa-solid fa-clock"></i> Waiting for buyer to accept your counter</div>' :
                  '<div class="offer-actions">' +
                    '<button class="btn btn-sm" style="background:var(--positive);color:#fff" data-accept="' + o.id + '">Accept</button>' +
                    '<button class="btn btn-sm btn-ghost" data-counter="' + o.id + '">Counter</button>' +
                    '<button class="btn btn-sm btn-secondary" data-decline="' + o.id + '">Decline</button>' +
                  '</div>') +
                '</div>';
        }).join('');
    }

    function soldList(items) {
        if (!items.length) return emptyBlock('circle-check', 'No sales yet', 'Vehicles you sell will show up here.');
        return items.map((l) =>
            '<div class="list-card"><div class="list-thumb"><div class="ph"><i class="fa-solid fa-car-side"></i></div></div>' +
            '<div class="list-info"><div class="list-title">' + esc(l.title) + '</div>' +
              '<div class="list-sub">' + timeAgo(l.sold_at) + ' · ' + esc((l.via || '').replace('_', ' ')) + '</div>' +
              '<div class="list-price" style="color:var(--positive)">+ ' + money(l.price) + '</div></div></div>').join('');
    }

    function expiredList(items) {
        if (!items.length) return emptyBlock('clock', 'No expired listings', 'Listings that expire will appear here to relist.');
        return items.map((l) =>
            '<div class="list-card"><div class="list-thumb"><div class="ph"><i class="fa-solid fa-car-side"></i></div></div>' +
            '<div class="list-info"><div class="list-title">' + esc(l.title) + '</div>' +
              '<div class="list-sub"><span class="status-tag expired">Expired</span> ' + money(l.price) + '</div>' +
              '<div class="list-actions"><button class="mini-btn accent" data-relist="' + l.id + '"><i class="fa-solid fa-rotate-right"></i> Relist</button></div>' +
            '</div></div>').join('');
    }

    function emptyBlock(icon, title, text) {
        return '<div class="empty"><i class="fa-solid fa-' + icon + '"></i><h3>' + title + '</h3><p>' + text + '</p></div>';
    }

    function bindDashboardActions(data) {
        const q = (sel) => rootEl.querySelectorAll(sel);

        q('[data-edit]').forEach((b) => b.onclick = async () => {
            const l = await api('getListing', { id: Number(b.dataset.edit) });
            if (!l) return toast('Could not load', 'err');
            state.sell = { mode: 'edit', listingId: l.id, vehicle: null, photos: [], category: l.category, condition: l.condition };
            state.view = 'sell';
            renderSell(l);
        });

        q('[data-price]').forEach((b) => b.onclick = async () => {
            const id = Number(b.dataset.price);
            const l = await api('getListing', { id });
            if (!l) return toast('Could not load', 'err');
            modal({
                icon: 'dollar-sign', title: 'Change Price', desc: 'Current price: ' + money(l.price),
                input: { type: 'number', placeholder: 'New price', value: l.price },
                confirmLabel: 'Update Price',
                onConfirm: async (val) => {
                    const p = parseInt(val, 10);
                    if (!p || p <= 0) return toast('Enter a valid price', 'err');
                    closeModal();
                    const r = await api('editListing', {
                        id: l.id, title: l.title, price: p, mileage: l.mileage, condition: l.condition,
                        category: l.category, description: l.description, contactNotes: l.contact,
                    });
                    if (r && r.success) { toast('Price updated'); renderDashboard(); }
                    else toast((r && r.message) || 'Could not update', 'err');
                }
            });
        });

        q('[data-photos]').forEach((b) => b.onclick = () => {
            state.sell.mode = 'edit'; state.sell.listingId = Number(b.dataset.photos); state.sell.photos = [];
            pickPhotos();
        });

        q('[data-remove]').forEach((b) => b.onclick = () => modal({
            icon: 'trash', danger: true, title: 'Remove Listing', desc: 'This will remove the listing from the marketplace. Your vehicle is not affected.',
            confirmLabel: 'Remove',
            onConfirm: async () => {
                closeModal();
                const r = await api('removeListing', { id: Number(b.dataset.remove) });
                if (r && r.success) { toast('Listing removed'); renderDashboard(); }
                else toast('Could not remove', 'err');
            }
        }));

        q('[data-relist]').forEach((b) => b.onclick = async () => {
            const r = await api('relist', { id: Number(b.dataset.relist) });
            if (r && r.success) { toast('Listing is live again'); renderDashboard(); }
            else toast((r && r.message) || 'Could not relist', 'err');
        });

        q('[data-accept]').forEach((b) => b.onclick = () => modal({
            icon: 'handshake', title: 'Accept Offer', desc: 'Accept this offer and sell the vehicle to the buyer?',
            confirmLabel: 'Accept & Sell',
            onConfirm: async () => {
                closeModal();
                const r = await api('offerAction', { offerId: Number(b.dataset.accept), action: 'accept' });
                if (r && r.success) { toast('Sold!'); renderDashboard(); }
                else toast((r && r.message) || 'Could not complete', 'err');
            }
        }));

        q('[data-decline]').forEach((b) => b.onclick = async () => {
            const r = await api('offerAction', { offerId: Number(b.dataset.decline), action: 'decline' });
            if (r && r.success) { toast('Offer declined'); renderDashboard(); }
        });

        q('[data-counter]').forEach((b) => b.onclick = () => modal({
            icon: 'arrow-right-arrow-left', title: 'Counter Offer', desc: 'Enter your counter amount.',
            input: { type: 'number', placeholder: 'Counter amount' },
            confirmLabel: 'Send Counter',
            onConfirm: async (val) => {
                const v = parseInt(val, 10);
                if (!v || v <= 0) return toast('Enter a valid amount', 'err');
                closeModal();
                const r = await api('offerAction', { offerId: Number(b.dataset.counter), action: 'counter', value: v });
                if (r && r.success) { toast('Counter sent'); renderDashboard(); }
                else toast((r && r.message) || 'Could not send', 'err');
            }
        }));
    }

    // =================================================================
    // BOOT
    // =================================================================
    async function boot() {
        state.meta = (await api('getMeta')) || {
            currency: '$', categories: [], maxImages: 8, minPrice: 1, maxPrice: 100000000,
        };
        if (state.meta.banned) {
            rootEl.innerHTML = '<div class="screen"><div class="empty" style="margin:auto"><i class="fa-solid fa-ban" style="color:var(--danger)"></i>' +
                '<h3>Marketplace access blocked</h3><p>You have been banned from AutoTrader LS. Contact staff if you believe this is a mistake.</p></div></div>';
            return;
        }
        setView('browse');
    }

    boot();
})();
